# Bounded SSPA epsilon trajectories

Development validation only. Uncertainty below is seed SD, not SE.

| Policy | Last conditional SWD | Last conditional GW2 | Last global SWD | Selected updates | Training seconds |
| --- | ---: | ---: | ---: | --- | ---: |
| legacy_separate_adaptive | 0.0456456 +/- 0.000273 | 0.190657 +/- 0.0014 | 0.0103833 +/- 0.000487 | 4800, 4800, 4800 | 21.0538 +/- 5.75 |
| fixed_common | 0.0454812 +/- 0.0002 | 0.190563 +/- 0.000918 | 0.00973569 +/- 0.000681 | 4800, 4800, 4800 | 13.586 +/- 0.0775 |
| shared_adaptive | 0.0455359 +/- 0.000439 | 0.189917 +/- 0.0013 | 0.0099717 +/- 0.000735 | 4800, 4800, 4800 | 20.2021 +/- 5.2 |

Common analytic anchor floors: SWD 0.0358438; GW2 0.144683.

```json
{
  "tasks": 9,
  "checkpoints": 54,
  "training_records": 432,
  "reference_attempts": 864,
  "reference_failures": 0,
  "max_reference_barycenter_rms": 0.04038349805218467,
  "max_postinitial_reference_barycenter_rms": 8.253564595747489e-07,
  "max_training_floor_fraction": 3.0517578125e-05,
  "max_training_row_relative": 0.05806529521942139,
  "training_seconds": 164.525411080278,
  "validation_seconds": 6.7426380950491875
}
```

These trajectories stop at the short operating budget; they cannot establish or exclude later collapse.
