# Same-input SSPA metric development test

Seed 7, three eight-dimensional inputs, eight fixed loss probes. No decoder training.
Reference loss gradients use Gaussian integration through the SSPA mean Jacobian.
Score and task samples are independent. Cross scores retain negative values.

Coverage: 192 metric records (144 learned), 1536 task records. Final sample counts: {0: 2048, 1: 2048, 2: 2048}.
Uncertainty below is MC SE across eight repetitions, not across independently trained models.
The 3-SE resolution rule is descriptive and uncalibrated; counts reuse model pairs across probes.

## Predeclared contrasts

Resolved target orderings: 72 / 72.
Candidate kernel added-information contrasts: 0 / 72.

| Comparator | Agrees with resolved target | Opposes | Unresolved |
|---|---:|---:|---:|
| swd | 48 | 24 | 0 |
| rbf_cross_value_squared | 48 | 24 | 0 |
| mean_derivative_cross | 54 | 18 | 0 |
| covariance_derivative_cross | 66 | 6 | 0 |
| moments_cross_trace | 61 | 3 | 8 |
| fourth_derivative_cross | 64 | 8 | 0 |
| rbf_cross_trace | 32 | 32 | 8 |

These counts describe this panel, not independent successes or a ranking benchmark.
An added-information contrast needs new model seeds and new probes before any selection claim.
A null count supplies no evidence of a kernel-specific advantage at this resolution.

## Per-input scores

Values are means +/- MC SE; self and cross columns are squared Hilbert-Schmidt quantities.
The noise term is self minus signed cross. It is candidate-specific, not subtracted using an analytic floor.

| Input | Model | SWD | RBF derivative cross | RBF derivative noise | Polynomial derivative cross |
|---|---|---:|---:|---:|---:|
| 0 | analytic | 0.0092884 +/- 0.00025 | -9.5512e-05 +/- 0.001 | 0.032872 +/- 0.001 | -7.9581e-06 +/- 2e-05 |
| 0 | ddim10 | 0.049055 +/- 0.00034 | 1.0881 +/- 0.011 | 0.030244 +/- 0.0012 | 0.046844 +/- 6.6e-05 |
| 0 | fiber_sinkhorn | 0.032558 +/- 0.00036 | 0.29545 +/- 0.006 | 0.034129 +/- 0.0015 | 0.086292 +/- 0.00022 |
| 0 | wgan | 0.097478 +/- 0.00046 | 1.0728 +/- 0.0097 | 0.034202 +/- 0.0016 | 0.10065 +/- 0.00029 |
| 1 | analytic | 0.0093013 +/- 0.00021 | 7.0103e-05 +/- 0.00049 | 0.020543 +/- 0.00081 | -3.944e-07 +/- 9.2e-06 |
| 1 | ddim10 | 0.048919 +/- 0.00035 | 0.7983 +/- 0.01 | 0.019408 +/- 0.0016 | 0.016473 +/- 5.6e-05 |
| 1 | fiber_sinkhorn | 0.02859 +/- 0.00038 | 0.19661 +/- 0.0041 | 0.021559 +/- 0.00092 | 0.054562 +/- 0.00019 |
| 1 | wgan | 0.072726 +/- 0.00046 | 0.73321 +/- 0.0097 | 0.023648 +/- 0.0012 | 0.066062 +/- 0.00031 |
| 2 | analytic | 0.0092998 +/- 0.00027 | -0.0029566 +/- 0.0056 | 0.17037 +/- 0.0069 | 5.8205e-05 +/- 5.2e-05 |
| 2 | ddim10 | 0.052476 +/- 0.00044 | 5.1038 +/- 0.076 | 0.15333 +/- 0.0075 | 0.34911 +/- 0.00099 |
| 2 | fiber_sinkhorn | 0.030038 +/- 0.00048 | 1.2211 +/- 0.021 | 0.15783 +/- 0.01 | 0.35111 +/- 0.0021 |
| 2 | wgan | 0.10976 +/- 0.00045 | 8.9584 +/- 0.036 | 0.14752 +/- 0.0036 | 1.2016 +/- 0.0046 |

## Absolute expected-gradient errors

Norm of the pooled gradient error across repetitions, followed by the L2 norm of coordinate MC SEs.
The latter describes sampling uncertainty, not a scalar norm confidence interval.

| Input | Probe | Analytic control | Conditional Sinkhorn | WGAN | DDIM-10 |
|---|---|---:|---:|---:|---:|
| 0 | direction0_rbf_section | 6.0642e-05 +/- 9.1e-05 | 0.0091334 +/- 0.0001 | 0.012568 +/- 7.6e-05 | 0.0040182 +/- 7e-05 |
| 0 | direction0_quadratic | 0.001334 +/- 0.00061 | 0.11253 +/- 0.00088 | 0.21997 +/- 0.0018 | 0.058232 +/- 0.00042 |
| 0 | direction0_logistic | 0.00017263 +/- 8.9e-05 | 0.056667 +/- 0.00042 | 0.11827 +/- 0.00086 | 0.031222 +/- 6.5e-05 |
| 0 | direction0_cosine | 0.00018925 +/- 6.9e-05 | 0.066771 +/- 0.0005 | 0.14181 +/- 0.00099 | 0.0388 +/- 9.2e-05 |
| 0 | direction1_rbf_section | 1.0477e-05 +/- 1.4e-05 | 0.0017759 +/- 1.6e-05 | 0.001704 +/- 1e-05 | 0.00070044 +/- 1e-05 |
| 0 | direction1_quadratic | 0.00087149 +/- 0.00055 | 0.34822 +/- 0.0023 | 0.36413 +/- 0.0023 | 0.10789 +/- 0.00088 |
| 0 | direction1_logistic | 0.00013122 +/- 7.1e-05 | 0.027999 +/- 0.0002 | 0.023235 +/- 0.0002 | 0.0081895 +/- 9.5e-05 |
| 0 | direction1_cosine | 7.9208e-05 +/- 0.00023 | 0.18688 +/- 0.0012 | 0.15805 +/- 0.0012 | 0.060227 +/- 0.00026 |
| 1 | direction0_rbf_section | 3.8543e-05 +/- 3e-05 | 0.0024111 +/- 3.8e-05 | 0.0056643 +/- 4.4e-05 | 0.0017489 +/- 2.3e-05 |
| 1 | direction0_quadratic | 5.7944e-05 +/- 0.00013 | 0.20006 +/- 0.0019 | 0.34115 +/- 0.0028 | 0.092504 +/- 0.00024 |
| 1 | direction0_logistic | 5.2642e-06 +/- 9.4e-06 | 0.075563 +/- 0.00071 | 0.12753 +/- 0.0011 | 0.035365 +/- 5e-05 |
| 1 | direction0_cosine | 3.2818e-05 +/- 0.0001 | 0.052874 +/- 0.00054 | 0.086109 +/- 0.00075 | 0.025965 +/- 0.00013 |
| 1 | direction1_rbf_section | 5.9662e-05 +/- 5.4e-05 | 0.0049282 +/- 7.4e-05 | 0.0086836 +/- 6.7e-05 | 0.0027556 +/- 4.6e-05 |
| 1 | direction1_quadratic | 0.00018582 +/- 0.00064 | 0.10798 +/- 0.0012 | 0.20418 +/- 0.0015 | 0.069722 +/- 0.00072 |
| 1 | direction1_logistic | 3.1535e-05 +/- 8.9e-05 | 0.050134 +/- 0.00054 | 0.1014 +/- 0.00079 | 0.035067 +/- 0.00012 |
| 1 | direction1_cosine | 5.3298e-05 +/- 6.6e-05 | 0.054978 +/- 0.00062 | 0.11935 +/- 0.00099 | 0.041527 +/- 6.4e-05 |
| 2 | direction0_rbf_section | 0.0004424 +/- 0.00024 | 0.019363 +/- 0.00029 | 0.039038 +/- 0.00039 | 0.012298 +/- 0.00022 |
| 2 | direction0_quadratic | 0.0013126 +/- 0.00068 | 0.30828 +/- 0.0029 | 0.72524 +/- 0.0032 | 0.453 +/- 0.0013 |
| 2 | direction0_logistic | 0.00025223 +/- 0.00012 | 0.047833 +/- 0.00052 | 0.078863 +/- 0.00048 | 0.070951 +/- 0.00019 |
| 2 | direction0_cosine | 0.00064371 +/- 0.00041 | 0.21189 +/- 0.0012 | 0.48697 +/- 0.0017 | 0.30905 +/- 0.00035 |
| 2 | direction1_rbf_section | 0.00017243 +/- 0.0001 | 0.0060991 +/- 8.5e-05 | 0.015164 +/- 9.9e-05 | 0.0044176 +/- 8.4e-05 |
| 2 | direction1_quadratic | 0.00076326 +/- 0.00071 | 0.10484 +/- 0.00092 | 0.29057 +/- 0.0013 | 0.03568 +/- 0.00053 |
| 2 | direction1_logistic | 0.00013154 +/- 0.00013 | 0.021394 +/- 0.00018 | 0.040392 +/- 0.00023 | 0.0069187 +/- 7.9e-05 |
| 2 | direction1_cosine | 0.00023227 +/- 0.00031 | 0.080571 +/- 0.00067 | 0.20297 +/- 0.00085 | 0.025184 +/- 0.0002 |

## Cost

Sampled outputs include a full input Jacobian for each draw.
Shared analytic score draws are counted once. Task and score draws are separate.

```json
{
  "sampled_outputs": {
    "reference_score": 122880,
    "analytic_score": 122880,
    "analytic_task": 122880,
    "fiber_sinkhorn_score": 122880,
    "fiber_sinkhorn_task": 122880,
    "wgan_score": 122880,
    "wgan_task": 122880,
    "ddim10_score": 122880,
    "ddim10_task": 122880
  },
  "timing_seconds": {
    "reference_score": 0.3492122349416604,
    "load_analytic_n512": 2.2021005861461163e-05,
    "analytic_score": 0.2503662919771159,
    "analytic_task": 0.1696546949679032,
    "metric_and_probe_algebra_n512": 23.87552628897538,
    "load_fiber_sinkhorn_n512": 0.0036162909964332357,
    "fiber_sinkhorn_score": 0.3708445960219251,
    "fiber_sinkhorn_task": 0.12707749805122148,
    "load_wgan_n512": 0.005799409991595894,
    "wgan_score": 0.26474461998441257,
    "wgan_task": 0.13818771493970416,
    "load_ddim10_n512": 0.004040871994220652,
    "ddim10_score": 1.3778716901142616,
    "ddim10_task": 1.3125951650581555,
    "load_analytic_n2048": 5.107399192638695e-05,
    "metric_and_probe_algebra_n2048": 578.2005060649972,
    "load_fiber_sinkhorn_n2048": 0.0033544629986863583,
    "load_wgan_n2048": 0.0034846570051740855,
    "load_ddim10_n2048": 0.003872390996548347
  },
  "elapsed_seconds": 611.0493327379954
}
```

N=512 and N=2048 raw summaries are both retained in the CSVs. No levels were pooled.
The analytic candidate supplies the independent task-noise control; no noisy reference task gradient is needed.
Quadratic probes test the moment baseline. The higher-order probes do not constitute downstream SER/BER.
