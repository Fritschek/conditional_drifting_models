# Pathwise and finite-difference channel metrics

Fixed empirical distributions with common random numbers across perturbations.
Analytic rows are independent sampling floors, not subtracted from scores.
Moment features: y/sqrt(d) and vec(yy^T)/d. Augmented kernel is their direct sum with RBF.
Means below average anchors and MC repeats; neither establishes population suprema.

| Channel | Model | Estimator | h | RBF value | RBF derivative | Moment value | Moment derivative | Augmented derivative |
|---|---|---|---:|---:|---:|---:|---:|---:|
| SSPA | analytic | pathwise | 0.0 | 0.0467927 | 0.35605 | 0.0253049 | 0.021949 | 0.356775 |
| SSPA | kernel_target | pathwise | 0.0 | 0.653469 | 3.2046 | 0.365147 | 1.04317 | 3.34824 |
| SSPA | joint_sinkhorn | pathwise | 0.0 | 0.626587 | 2.66253 | 0.452144 | 1.09845 | 2.86194 |
| SSPA | fiber_sinkhorn | pathwise | 0.0 | 0.106779 | 0.663746 | 0.0669126 | 0.285324 | 0.702122 |
| SSPA | wgan | pathwise | 0.0 | 0.14661 | 1.00706 | 0.103872 | 0.317962 | 1.04883 |
| SSPA | ddim10 | pathwise | 0.0 | 0.152098 | 1.21398 | 0.0417182 | 0.231379 | 1.22532 |
| SSPA | ddim100 | pathwise | 0.0 | 0.0588568 | 0.476977 | 0.0405048 | 0.235972 | 0.527928 |
| SSPA | fiber_full | pathwise | 0.0 | 0.360499 | 1.84501 | 11.4977 | 2.04871 | 2.48434 |
