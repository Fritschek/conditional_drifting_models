# Local gradient-fidelity pilot

Existing checkpoint seed only. Independent Monte Carlo repeats are not training seeds.
All methods use the same frozen codec within each comparison. Gradients are expected
cross-entropy gradients, not samplewise Jacobian comparisons between different latent draws.
Full-alphabet centering and unit RMS replace minibatch power normalization for this test.
Noise stays fixed under perturbations. These are not reruns of the paper's SER protocol.

## SSPA/analytic

Analytic-channel baseline CE: 4.04945e-05; SER: 4.76837e-06.

| Model | Conditional SWD | Global SWD at codewords | Input gradient cosine | Encoder gradient cosine | Encoder norm ratio | Relative input-gradient error |
|---|---:|---:|---:|---:|---:|---:|
| analytic | 0.012925 | 0.0035517 | 0.7146 | 0.8358 | 1.24 | 0.922 |
| kernel_target | 0.19697 | 0.11278 | -0.0112 | 0.1397 | 0.000684 | 1 |
| joint_sinkhorn | 0.18997 | 0.1181 | 0.0176 | 0.5065 | 0.00295 | 1 |
| fiber_sinkhorn | 0.027562 | 0.0097712 | 0.5407 | 0.4533 | 0.594 | 0.849 |
| wgan | 0.040321 | 0.025164 | 0.4593 | 0.6773 | 1.54 | 1.2 |
| ddim10 | 0.049354 | 0.015103 | 0.7180 | 0.8498 | 0.0289 | 0.982 |
| ddim100 | 0.017135 | 0.0065245 | 0.7058 | 0.8486 | 0.954 | 0.79 |
| fiber_full | 1.7309 | 1.4318 | 0.1436 | 0.2635 | 2.32e+04 | 6.82e+03 |

Analytic row is an independent, equal-sample Monte Carlo gradient and SWD floor.
Reference gradients use more samples; uncertainty and repeat-level values are in JSON.

### Single Encoder Steps on the Analytic Channel

Decoder frozen; normalized parameter steps, followed by full-codebook normalization.
Step normalization isolates direction and does not test the effect of erroneous gradient magnitudes.
Paired common-noise evaluation is independent of gradient estimation.
CE delta uncertainty is Monte Carlo SE across repeats, not training-seed variability.

| Model | Relative parameter step | Analytic CE delta | MC SE | First-order prediction | SER after step |
|---|---:|---:|---:|---:|---:|
| analytic | 0.0001 | -5.3711e-07 | 5.3e-08 | -4.9678e-07 | 4.7684e-06 |
| analytic | 0.0003 | -1.4617e-06 | 1.6e-07 | -1.4903e-06 | 4.7684e-06 |
| analytic | 0.001 | -3.2903e-06 | 5.3e-07 | -4.9678e-06 | 4.2915e-06 |
| kernel_target | 0.0001 | -1.027e-07 | 2.8e-08 | -8.3034e-08 | 4.7684e-06 |
| kernel_target | 0.0003 | -2.753e-07 | 8.3e-08 | -2.491e-07 | 4.7684e-06 |
| kernel_target | 0.001 | -5.3756e-07 | 2.8e-07 | -8.3034e-07 | 4.53e-06 |
| joint_sinkhorn | 0.0001 | -3.8666e-07 | 3.7e-08 | -3.0107e-07 | 4.7684e-06 |
| joint_sinkhorn | 0.0003 | -1.0503e-06 | 1.1e-07 | -9.0322e-07 | 4.53e-06 |
| joint_sinkhorn | 0.001 | -2.2827e-06 | 3.9e-07 | -3.0107e-06 | 4.0531e-06 |
| fiber_sinkhorn | 0.0001 | -2.9041e-07 | 1.8e-08 | -2.6944e-07 | 4.53e-06 |
| fiber_sinkhorn | 0.0003 | -6.9529e-07 | 5.4e-08 | -8.0833e-07 | 4.53e-06 |
| fiber_sinkhorn | 0.001 | -3.713e-07 | 1.8e-07 | -2.6944e-06 | 4.2915e-06 |
| wgan | 0.0001 | -3.9375e-07 | 3.2e-08 | -4.0256e-07 | 4.53e-06 |
| wgan | 0.0003 | -9.8089e-07 | 9.8e-08 | -1.2077e-06 | 4.7684e-06 |
| wgan | 0.001 | -1.1584e-06 | 3.7e-07 | -4.0256e-06 | 4.53e-06 |
| ddim10 | 0.0001 | -5.7148e-07 | 6e-08 | -5.0511e-07 | 4.7684e-06 |
| ddim10 | 0.0003 | -1.5516e-06 | 1.8e-07 | -1.5153e-06 | 4.7684e-06 |
| ddim10 | 0.001 | -3.4542e-06 | 5.9e-07 | -5.0511e-06 | 4.53e-06 |
| ddim100 | 0.0001 | -5.3828e-07 | 6e-08 | -5.044e-07 | 4.53e-06 |
| ddim100 | 0.0003 | -1.4757e-06 | 1.8e-07 | -1.5132e-06 | 4.7684e-06 |
| ddim100 | 0.001 | -3.4457e-06 | 5.8e-07 | -5.044e-06 | 4.2915e-06 |
| fiber_full | 0.0001 | -1.7597e-07 | 4.6e-08 | -1.5664e-07 | 4.7684e-06 |
| fiber_full | 0.0003 | -4.0061e-07 | 1.4e-07 | -4.6991e-07 | 4.7684e-06 |
| fiber_full | 0.001 | 1.2207e-07 | 4.4e-07 | -1.5664e-06 | 4.2915e-06 |

## SSPA/fiber_sinkhorn

Analytic-channel baseline CE: 0.000267384; SER: 7.29561e-05.

| Model | Conditional SWD | Global SWD at codewords | Input gradient cosine | Encoder gradient cosine | Encoder norm ratio | Relative input-gradient error |
|---|---:|---:|---:|---:|---:|---:|
| analytic | 0.012925 | 0.0034221 | 0.9902 | 0.9862 | 1.33 | 0.267 |
| kernel_target | 0.19455 | 0.10292 | 0.6683 | 0.7198 | 25 | 26 |
| joint_sinkhorn | 0.19325 | 0.11509 | 0.0230 | 0.1011 | 353 | 332 |
| fiber_sinkhorn | 0.032206 | 0.011148 | 0.1970 | 0.4249 | 0.0336 | 0.995 |
| wgan | 0.040225 | 0.024273 | 0.3917 | 0.5063 | 0.36 | 0.929 |
| ddim10 | 0.049191 | 0.014503 | 0.9333 | 0.9489 | 0.0547 | 0.952 |
| ddim100 | 0.016821 | 0.005465 | 0.9476 | 0.9225 | 0.657 | 0.446 |
| fiber_full | 1.7285 | 1.4283 | 0.0390 | 0.2184 | 2.53e+03 | 605 |

Analytic row is an independent, equal-sample Monte Carlo gradient and SWD floor.
Reference gradients use more samples; uncertainty and repeat-level values are in JSON.

### Single Encoder Steps on the Analytic Channel

Decoder frozen; normalized parameter steps, followed by full-codebook normalization.
Step normalization isolates direction and does not test the effect of erroneous gradient magnitudes.
Paired common-noise evaluation is independent of gradient estimation.
CE delta uncertainty is Monte Carlo SE across repeats, not training-seed variability.

| Model | Relative parameter step | Analytic CE delta | MC SE | First-order prediction | SER after step |
|---|---:|---:|---:|---:|---:|
| analytic | 0.0001 | -6.413e-06 | 2e-07 | -6.2836e-06 | 7.0572e-05 |
| analytic | 0.0003 | -1.7478e-05 | 5.8e-07 | -1.8851e-05 | 6.5804e-05 |
| analytic | 0.001 | -3.9458e-05 | 1.8e-06 | -6.2836e-05 | 5.9128e-05 |
| kernel_target | 0.0001 | -4.8465e-06 | 2.3e-07 | -4.5864e-06 | 7.1049e-05 |
| kernel_target | 0.0003 | -1.3284e-05 | 7e-07 | -1.3759e-05 | 6.6757e-05 |
| kernel_target | 0.001 | -2.9969e-05 | 2.5e-06 | -4.5864e-05 | 6.3419e-05 |
| joint_sinkhorn | 0.0001 | -5.425e-07 | 2.2e-07 | -6.4393e-07 | 7.1526e-05 |
| joint_sinkhorn | 0.0003 | -4.9335e-07 | 6.7e-07 | -1.9318e-06 | 7.1764e-05 |
| joint_sinkhorn | 0.001 | 1.3048e-05 | 2.4e-06 | -6.4393e-06 | 7.844e-05 |
| fiber_sinkhorn | 0.0001 | -2.6117e-06 | 1.4e-07 | -2.7072e-06 | 7.1764e-05 |
| fiber_sinkhorn | 0.0003 | -7.1129e-06 | 4.1e-07 | -8.1216e-06 | 7.0572e-05 |
| fiber_sinkhorn | 0.001 | -1.5514e-05 | 1.2e-06 | -2.7072e-05 | 6.6519e-05 |
| wgan | 0.0001 | -3.1967e-06 | 1.4e-07 | -3.2258e-06 | 7.1526e-05 |
| wgan | 0.0003 | -8.6519e-06 | 4e-07 | -9.6774e-06 | 6.8903e-05 |
| wgan | 0.001 | -1.8248e-05 | 1.1e-06 | -3.2258e-05 | 6.5327e-05 |
| ddim10 | 0.0001 | -6.2289e-06 | 1.9e-07 | -6.046e-06 | 7.081e-05 |
| ddim10 | 0.0003 | -1.6978e-05 | 5.6e-07 | -1.8138e-05 | 6.628e-05 |
| ddim10 | 0.001 | -3.8122e-05 | 1.8e-06 | -6.046e-05 | 6.0081e-05 |
| ddim100 | 0.0001 | -6.0203e-06 | 1.9e-07 | -5.8777e-06 | 7.1049e-05 |
| ddim100 | 0.0003 | -1.6509e-05 | 5.5e-07 | -1.7633e-05 | 6.7234e-05 |
| ddim100 | 0.001 | -3.8366e-05 | 1.7e-06 | -5.8777e-05 | 5.9605e-05 |
| fiber_full | 0.0001 | -1.3154e-06 | 7.1e-08 | -1.3914e-06 | 7.2002e-05 |
| fiber_full | 0.0003 | -3.5755e-06 | 2.1e-07 | -4.1743e-06 | 7.1287e-05 |
| fiber_full | 0.001 | -7.5778e-06 | 5.8e-07 | -1.3914e-05 | 6.8665e-05 |
