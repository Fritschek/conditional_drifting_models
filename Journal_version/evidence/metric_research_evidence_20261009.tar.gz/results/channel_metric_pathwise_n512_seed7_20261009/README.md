# Pathwise and finite-difference channel metrics

Fixed empirical distributions with common random numbers across perturbations.
Analytic rows are independent sampling floors, not subtracted from scores.
Moment features: y/sqrt(d) and vec(yy^T)/d. Augmented kernel is their direct sum with RBF.
Means below average anchors and MC repeats; neither establishes population suprema.

| Channel | Model | Estimator | h | RBF value | RBF derivative | Moment value | Moment derivative | Augmented derivative |
|---|---|---|---:|---:|---:|---:|---:|---:|
| AWGN | analytic | pathwise | 0.0 | 0.0461895 | 0.063272 | 0.0620619 | 0.0237989 | 0.0668272 |
| AWGN | kernel_target | pathwise | 0.0 | 0.536906 | 0.943408 | 0.430486 | 0.34695 | 1.01829 |
| AWGN | joint_sinkhorn | pathwise | 0.0 | 0.072235 | 0.111396 | 0.116546 | 0.142859 | 0.185967 |
| AWGN | fiber_sinkhorn | pathwise | 0.0 | 0.0481637 | 0.0649714 | 0.0656511 | 0.0339339 | 0.07202 |
| AWGN | wgan | pathwise | 0.0 | 0.056566 | 0.0759987 | 0.0955393 | 0.0678773 | 0.101212 |
| AWGN | ddim10 | pathwise | 0.0 | 0.0855627 | 0.110575 | 0.0662879 | 0.0253809 | 0.112418 |
| AWGN | ddim100 | pathwise | 0.0 | 0.047515 | 0.0653219 | 0.0640671 | 0.0266643 | 0.0694605 |
| SSPA | analytic | pathwise | 0.0 | 0.0467927 | 0.35605 | 0.0253049 | 0.021949 | 0.356775 |
| SSPA | kernel_target | pathwise | 0.0 | 0.690062 | 3.4573 | 0.376996 | 1.04247 | 3.59089 |
| SSPA | joint_sinkhorn | pathwise | 0.0 | 0.69582 | 3.01967 | 0.524605 | 1.21435 | 3.2326 |
| SSPA | fiber_sinkhorn | pathwise | 0.0 | 0.101483 | 0.619583 | 0.0697854 | 0.286569 | 0.663335 |
| SSPA | wgan | pathwise | 0.0 | 0.230655 | 1.26044 | 0.191285 | 0.39005 | 1.3109 |
| SSPA | ddim10 | pathwise | 0.0 | 0.153948 | 1.24285 | 0.0404005 | 0.254988 | 1.25678 |
| SSPA | ddim100 | pathwise | 0.0 | 0.0604754 | 0.511757 | 0.0418583 | 0.243836 | 0.561 |
| SSPA | fiber_full | pathwise | 0.0 | 0.414884 | 1.93133 | 8.19176 | 4.51884 | 4.7263 |
