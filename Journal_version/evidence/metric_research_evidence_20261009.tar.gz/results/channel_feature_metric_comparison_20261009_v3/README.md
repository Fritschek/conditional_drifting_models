# Decoder-free scores and existing task diagnostics

Post-hoc development comparison. Scores use fixed generic inputs and no decoder.
Task gradients use learned codewords and frozen codecs; these are different input panels.
Higher-sample gradient results replace only the models rerun; per-row gradient budgets and sources are in CSV.
No score was fitted, and these known seed-7 cases are not a held-out validation set.

![Derivative sampling floor](derivative_sampling_floor.png)

## Middle perturbation size (h=0.05), shared noise

All step sizes and both noise regimes are retained in the source results and joined CSV.

| Channel | N | Model | MMD | Embedding derivative | Mean derivative | Covariance error | Covariance derivative | Encoder relative error, analytic codec | Encoder relative error, Sinkhorn codec |
|---|---:|---|---:|---:|---:|---:|---:|---:|---:|
| AWGN | 128 | analytic | 0.0965 | 0.1307 | 8.28e-08 | 0.2715 | 1.78e-07 | 0.2552 | 0.3224 |
| AWGN | 128 | kernel_target | 0.5423 | 0.9503 | 0.2278 | 0.7312 | 0.004986 | 1 | 1 |
| AWGN | 128 | joint_sinkhorn | 0.1069 | 0.1576 | 0.1261 | 0.2688 | 0.05301 | 1.079 | 0.9284 |
| AWGN | 128 | fiber_sinkhorn | 0.09448 | 0.1281 | 0.02946 | 0.249 | 0.02405 | 0.4119 | 0.3887 |
| AWGN | 128 | wgan | 0.1008 | 0.1366 | 0.06639 | 0.2748 | 0.06503 | 0.7345 | 0.7163 |
| AWGN | 128 | ddim10 | 0.1191 | 0.1616 | 0.01112 | 0.3037 | 0.003987 | 0.6997 | 0.7239 |
| AWGN | 128 | ddim100 | 0.0971 | 0.1318 | 0.009606 | 0.2685 | 0.003952 | 0.2505 | 0.3393 |
| SSPA | 128 | analytic | 0.09459 | 0.6304 | 9.371e-08 | 0.05483 | 8.205e-08 | 0.0598 | 0.1173 |
| SSPA | 128 | kernel_target | 0.6966 | 3.335 | 1.55 | 0.1475 | 0.008066 | 0.9992 | 0.9999 |
| SSPA | 128 | joint_sinkhorn | 0.6996 | 2.921 | 1.779 | 0.132 | 0.03624 | 0.9983 | 0.9748 |
| SSPA | 128 | fiber_sinkhorn | 0.132 | 0.7857 | 0.4031 | 0.06744 | 0.07746 | 0.6142 | 0.9253 |
| SSPA | 128 | wgan | 0.2419 | 1.27 | 0.5426 | 0.1342 | 0.3055 | 3.057 | 4.018 |
| SSPA | 128 | ddim10 | 0.1723 | 1.232 | 0.3801 | 0.07977 | 0.007593 | 0.9541 | 0.9677 |
| SSPA | 128 | ddim100 | 0.1012 | 0.6974 | 0.3591 | 0.05424 | 0.009557 | 0.1592 | 0.2635 |
| SSPA | 128 | fiber_full | 0.4251 | 1.873 | 0.6287 | 68.69 | 42.63 | 2270 | 2549 |
| AWGN | 512 | analytic | 0.04604 | 0.06321 | 3.668e-08 | 0.1307 | 8.399e-08 | 0.2552 | 0.3224 |
| AWGN | 512 | fiber_sinkhorn | 0.04836 | 0.06559 | 0.02786 | 0.1285 | 0.0193 | 0.4119 | 0.3887 |
| AWGN | 512 | ddim10 | 0.08538 | 0.1101 | 0.01112 | 0.2211 | 0.003883 | 0.6997 | 0.7239 |
| AWGN | 512 | ddim100 | 0.04726 | 0.06518 | 0.009614 | 0.1301 | 0.003855 | 0.2505 | 0.3393 |
| SSPA | 512 | analytic | 0.0472 | 0.3128 | 4.565e-08 | 0.02808 | 4.358e-08 | 0.0598 | 0.1173 |
| SSPA | 512 | fiber_sinkhorn | 0.1018 | 0.5615 | 0.3999 | 0.04977 | 0.07125 | 0.6142 | 0.9253 |
| SSPA | 512 | ddim10 | 0.1541 | 1.099 | 0.38 | 0.07046 | 0.007501 | 0.9541 | 0.9677 |
| SSPA | 512 | ddim100 | 0.06033 | 0.4332 | 0.3589 | 0.02854 | 0.009533 | 0.1592 | 0.2635 |
| SSPA | 512 | fiber_full | 0.4151 | 1.794 | 0.4365 | 66.74 | 38.36 | 2270 | 2549 |
