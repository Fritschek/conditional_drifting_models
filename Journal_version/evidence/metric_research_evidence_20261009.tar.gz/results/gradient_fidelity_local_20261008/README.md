# Local gradient-fidelity pilot

Existing checkpoint seed only. Independent Monte Carlo repeats are not training seeds.
All methods use the same frozen codec within each comparison. Gradients are expected
cross-entropy gradients, not samplewise Jacobian comparisons between different latent draws.
Full-alphabet centering and unit RMS replace minibatch power normalization for this test.
Noise stays fixed under perturbations. These are not reruns of the paper's SER protocol.

## AWGN/analytic

Analytic-channel baseline CE: 0.0162584; SER: 0.00552845.

| Model | Conditional SWD | Global SWD at codewords | Input gradient cosine | Encoder gradient cosine | Relative input-gradient error |
|---|---:|---:|---:|---:|---:|
| analytic | 0.030924 | 0.010368 | 0.9893 | 0.9750 | 0.148 |
| kernel_target | 0.36801 | 0.12929 | 0.2999 | 0.1548 | 1 |
| joint_sinkhorn | 0.047453 | 0.021926 | 0.9383 | 0.4479 | 0.481 |
| fiber_sinkhorn | 0.030865 | 0.010604 | 0.9846 | 0.9478 | 0.175 |
| wgan | 0.039387 | 0.025159 | 0.9794 | 0.8895 | 0.218 |
| ddim10 | 0.064308 | 0.031328 | 0.9633 | 0.9552 | 0.776 |
| ddim100 | 0.03087 | 0.010945 | 0.9889 | 0.9682 | 0.165 |

Analytic row is an independent, equal-sample Monte Carlo gradient and SWD floor.
Reference gradients use more samples; uncertainty and repeat-level values are in JSON.

### Single Encoder Steps on the Analytic Channel

Decoder frozen; normalized parameter steps, followed by full-codebook normalization.
Paired common-noise evaluation is independent of gradient estimation.
CE delta uncertainty is Monte Carlo SE across repeats, not training-seed variability.

| Model | Relative parameter step | Analytic CE delta | MC SE | First-order prediction | SER after step |
|---|---:|---:|---:|---:|---:|
| analytic | 0.0001 | -3.0666e-05 | 6.4e-07 | -3.1135e-05 | 0.005518 |
| analytic | 0.0003 | -8.8909e-05 | 1.9e-06 | -9.3406e-05 | 0.0054874 |
| analytic | 0.001 | -0.00026051 | 6.6e-06 | -0.00031135 | 0.0054264 |
| kernel_target | 0.0001 | -4.0613e-06 | 4.4e-07 | -4.9416e-06 | 0.0055361 |
| kernel_target | 0.0003 | -1.0098e-05 | 1.3e-06 | -1.4825e-05 | 0.0055075 |
| kernel_target | 0.001 | -9.7719e-06 | 4.3e-06 | -4.9416e-05 | 0.0054941 |
| joint_sinkhorn | 0.0001 | -1.297e-05 | 4.2e-07 | -1.4303e-05 | 0.0055285 |
| joint_sinkhorn | 0.0003 | -3.5257e-05 | 1.2e-06 | -4.291e-05 | 0.0055094 |
| joint_sinkhorn | 0.001 | -7.5057e-05 | 4.2e-06 | -0.00014303 | 0.005496 |
| fiber_sinkhorn | 0.0001 | -3.0012e-05 | 8.2e-07 | -3.0266e-05 | 0.0055199 |
| fiber_sinkhorn | 0.0003 | -8.6586e-05 | 2.5e-06 | -9.0797e-05 | 0.0054903 |
| fiber_sinkhorn | 0.001 | -0.00024885 | 8.5e-06 | -0.00030266 | 0.0054369 |
| wgan | 0.0001 | -2.8585e-05 | 9.2e-07 | -2.8404e-05 | 0.005518 |
| wgan | 0.0003 | -8.212e-05 | 2.8e-06 | -8.5212e-05 | 0.0054893 |
| wgan | 0.001 | -0.00023191 | 9.6e-06 | -0.00028404 | 0.0054464 |
| ddim10 | 0.0001 | -3.0039e-05 | 6.2e-07 | -3.0502e-05 | 0.0055161 |
| ddim10 | 0.0003 | -8.7056e-05 | 1.9e-06 | -9.1506e-05 | 0.0054893 |
| ddim10 | 0.001 | -0.00025489 | 6.4e-06 | -0.00030502 | 0.0054369 |
| ddim100 | 0.0001 | -3.06e-05 | 6.5e-07 | -3.0917e-05 | 0.0055161 |
| ddim100 | 0.0003 | -8.8783e-05 | 2e-06 | -9.2752e-05 | 0.0054874 |
| ddim100 | 0.001 | -0.00026104 | 6.7e-06 | -0.00030917 | 0.0054417 |

## AWGN/fiber_sinkhorn

Analytic-channel baseline CE: 0.0164128; SER: 0.00546837.

| Model | Conditional SWD | Global SWD at codewords | Input gradient cosine | Encoder gradient cosine | Relative input-gradient error |
|---|---:|---:|---:|---:|---:|
| analytic | 0.030924 | 0.010255 | 0.9910 | 0.9510 | 0.134 |
| kernel_target | 0.36837 | 0.13532 | 0.3005 | 0.5603 | 1 |
| joint_sinkhorn | 0.047805 | 0.020846 | 0.9475 | 0.6263 | 0.473 |
| fiber_sinkhorn | 0.030582 | 0.009974 | 0.9917 | 0.9432 | 0.151 |
| wgan | 0.0412 | 0.026608 | 0.9781 | 0.7549 | 0.216 |
| ddim10 | 0.064174 | 0.032256 | 0.9629 | 0.8938 | 0.774 |
| ddim100 | 0.030619 | 0.011038 | 0.9906 | 0.9415 | 0.163 |

Analytic row is an independent, equal-sample Monte Carlo gradient and SWD floor.
Reference gradients use more samples; uncertainty and repeat-level values are in JSON.

### Single Encoder Steps on the Analytic Channel

Decoder frozen; normalized parameter steps, followed by full-codebook normalization.
Paired common-noise evaluation is independent of gradient estimation.
CE delta uncertainty is Monte Carlo SE across repeats, not training-seed variability.

| Model | Relative parameter step | Analytic CE delta | MC SE | First-order prediction | SER after step |
|---|---:|---:|---:|---:|---:|
| analytic | 0.0001 | -2.8948e-05 | 1.2e-06 | -3.1235e-05 | 0.005455 |
| analytic | 0.0003 | -8.4022e-05 | 3.6e-06 | -9.3704e-05 | 0.0054188 |
| analytic | 0.001 | -0.00024738 | 1.2e-05 | -0.00031235 | 0.0053492 |
| kernel_target | 0.0001 | -1.5374e-05 | 5e-07 | -1.8401e-05 | 0.0054626 |
| kernel_target | 0.0003 | -4.3349e-05 | 1.5e-06 | -5.5202e-05 | 0.0054369 |
| kernel_target | 0.001 | -0.0001122 | 5.1e-06 | -0.00018401 | 0.0054121 |
| joint_sinkhorn | 0.0001 | -1.8766e-05 | 5.1e-07 | -2.057e-05 | 0.0054502 |
| joint_sinkhorn | 0.0003 | -5.2664e-05 | 1.5e-06 | -6.1711e-05 | 0.0054321 |
| joint_sinkhorn | 0.001 | -0.00013316 | 4.9e-06 | -0.0002057 | 0.0054131 |
| fiber_sinkhorn | 0.0001 | -2.9417e-05 | 1e-06 | -3.0978e-05 | 0.0054531 |
| fiber_sinkhorn | 0.0003 | -8.6047e-05 | 3e-06 | -9.2933e-05 | 0.0054283 |
| fiber_sinkhorn | 0.001 | -0.0002616 | 1e-05 | -0.00030978 | 0.0053453 |
| wgan | 0.0001 | -2.2646e-05 | 8.2e-07 | -2.4794e-05 | 0.0054607 |
| wgan | 0.0003 | -6.5625e-05 | 2.5e-06 | -7.4381e-05 | 0.0054407 |
| wgan | 0.001 | -0.00019192 | 8.6e-06 | -0.00024794 | 0.0053864 |
| ddim10 | 0.0001 | -2.8028e-05 | 1.1e-06 | -2.9356e-05 | 0.0054541 |
| ddim10 | 0.0003 | -8.1204e-05 | 3.3e-06 | -8.8067e-05 | 0.0054283 |
| ddim10 | 0.001 | -0.00023758 | 1.1e-05 | -0.00029356 | 0.005372 |
| ddim100 | 0.0001 | -2.8742e-05 | 1.1e-06 | -3.0922e-05 | 0.005455 |
| ddim100 | 0.0003 | -8.3352e-05 | 3.4e-06 | -9.2766e-05 | 0.0054207 |
| ddim100 | 0.001 | -0.00024475 | 1.1e-05 | -0.00030922 | 0.0053587 |

## SSPA/analytic

Analytic-channel baseline CE: 0.000262692; SER: 4.86374e-05.

| Model | Conditional SWD | Global SWD at codewords | Input gradient cosine | Encoder gradient cosine | Relative input-gradient error |
|---|---:|---:|---:|---:|---:|
| analytic | 0.012925 | 0.0035139 | 0.9237 | 0.9897 | 0.393 |
| kernel_target | 0.20174 | 0.11237 | 0.4923 | 0.8402 | 0.999 |
| joint_sinkhorn | 0.2015 | 0.1255 | 0.4094 | 0.7633 | 0.998 |
| fiber_sinkhorn | 0.030036 | 0.011035 | 0.6684 | 0.7907 | 0.746 |
| wgan | 0.088509 | 0.080824 | 0.3015 | 0.2393 | 2.85 |
| ddim10 | 0.048961 | 0.014148 | 0.7364 | 0.9350 | 0.958 |
| ddim100 | 0.016235 | 0.0051401 | 0.8836 | 0.9830 | 0.468 |
| fiber_full | 1.8391 | 1.6087 | 0.1061 | 0.7171 | 2.65e+03 |

Analytic row is an independent, equal-sample Monte Carlo gradient and SWD floor.
Reference gradients use more samples; uncertainty and repeat-level values are in JSON.

### Single Encoder Steps on the Analytic Channel

Decoder frozen; normalized parameter steps, followed by full-codebook normalization.
Paired common-noise evaluation is independent of gradient estimation.
CE delta uncertainty is Monte Carlo SE across repeats, not training-seed variability.

| Model | Relative parameter step | Analytic CE delta | MC SE | First-order prediction | SER after step |
|---|---:|---:|---:|---:|---:|
| analytic | 0.0001 | -6.4015e-06 | 1.3e-07 | -7.1211e-06 | 4.6015e-05 |
| analytic | 0.0003 | -1.7237e-05 | 3.8e-07 | -2.1363e-05 | 4.1723e-05 |
| analytic | 0.001 | -3.701e-05 | 1e-06 | -7.1211e-05 | 3.5763e-05 |
| kernel_target | 0.0001 | -5.3816e-06 | 1.4e-07 | -6.0452e-06 | 4.5776e-05 |
| kernel_target | 0.0003 | -1.41e-05 | 4e-07 | -1.8136e-05 | 4.2915e-05 |
| kernel_target | 0.001 | -2.5341e-05 | 1.3e-06 | -6.0452e-05 | 3.9101e-05 |
| joint_sinkhorn | 0.0001 | -4.8204e-06 | 6e-08 | -5.4919e-06 | 4.6015e-05 |
| joint_sinkhorn | 0.0003 | -1.2775e-05 | 1.7e-07 | -1.6476e-05 | 4.4107e-05 |
| joint_sinkhorn | 0.001 | -2.4799e-05 | 4.7e-07 | -5.4919e-05 | 4.0531e-05 |
| fiber_sinkhorn | 0.0001 | -4.9606e-06 | 1.1e-07 | -5.6897e-06 | 4.6492e-05 |
| fiber_sinkhorn | 0.0003 | -1.312e-05 | 3e-07 | -1.7069e-05 | 4.53e-05 |
| fiber_sinkhorn | 0.001 | -2.5228e-05 | 8.4e-07 | -5.6897e-05 | 3.9577e-05 |
| wgan | 0.0001 | -1.2973e-06 | 2.5e-07 | -1.7216e-06 | 4.7922e-05 |
| wgan | 0.0003 | -2.3856e-06 | 7.4e-07 | -5.1647e-06 | 4.8637e-05 |
| wgan | 0.001 | 9.202e-06 | 2.3e-06 | -1.7216e-05 | 5.2214e-05 |
| ddim10 | 0.0001 | -5.9616e-06 | 1.3e-07 | -6.7279e-06 | 4.5776e-05 |
| ddim10 | 0.0003 | -1.5873e-05 | 3.8e-07 | -2.0184e-05 | 4.1008e-05 |
| ddim10 | 0.001 | -3.1934e-05 | 1.1e-06 | -6.7279e-05 | 3.7193e-05 |
| ddim100 | 0.0001 | -6.3599e-06 | 1.3e-07 | -7.0731e-06 | 4.6015e-05 |
| ddim100 | 0.0003 | -1.7156e-05 | 3.7e-07 | -2.1219e-05 | 4.1246e-05 |
| ddim100 | 0.001 | -3.7186e-05 | 9.9e-07 | -7.0731e-05 | 3.624e-05 |
| fiber_full | 0.0001 | -4.5349e-06 | 1.4e-07 | -5.1599e-06 | 4.7207e-05 |
| fiber_full | 0.0003 | -1.2134e-05 | 3.9e-07 | -1.548e-05 | 4.3869e-05 |
| fiber_full | 0.001 | -2.4589e-05 | 1.1e-06 | -5.1599e-05 | 4.0054e-05 |

## SSPA/fiber_sinkhorn

Analytic-channel baseline CE: 0.000534476; SER: 0.000159264.

| Model | Conditional SWD | Global SWD at codewords | Input gradient cosine | Encoder gradient cosine | Relative input-gradient error |
|---|---:|---:|---:|---:|---:|
| analytic | 0.012925 | 0.0035022 | 0.9606 | 0.9565 | 0.279 |
| kernel_target | 0.19877 | 0.1083 | 0.4391 | 0.3780 | 1 |
| joint_sinkhorn | 0.19387 | 0.12333 | 0.4181 | 0.5573 | 0.983 |
| fiber_sinkhorn | 0.030315 | 0.010049 | 0.3636 | 0.4879 | 0.966 |
| wgan | 0.090095 | 0.081535 | 0.3554 | 0.0577 | 2.55 |
| ddim10 | 0.048882 | 0.014806 | 0.6889 | 0.5227 | 0.958 |
| ddim100 | 0.015954 | 0.005173 | 0.9537 | 0.9528 | 0.329 |
| fiber_full | 1.8596 | 1.6292 | 0.0518 | 0.0651 | 1.12e+03 |

Analytic row is an independent, equal-sample Monte Carlo gradient and SWD floor.
Reference gradients use more samples; uncertainty and repeat-level values are in JSON.

### Single Encoder Steps on the Analytic Channel

Decoder frozen; normalized parameter steps, followed by full-codebook normalization.
Paired common-noise evaluation is independent of gradient estimation.
CE delta uncertainty is Monte Carlo SE across repeats, not training-seed variability.

| Model | Relative parameter step | Analytic CE delta | MC SE | First-order prediction | SER after step |
|---|---:|---:|---:|---:|---:|
| analytic | 0.0001 | -7.5985e-06 | 3.2e-07 | -7.6992e-06 | 0.00015712 |
| analytic | 0.0003 | -2.1952e-05 | 9.3e-07 | -2.3098e-05 | 0.0001514 |
| analytic | 0.001 | -6.408e-05 | 2.8e-06 | -7.6992e-05 | 0.00013971 |
| kernel_target | 0.0001 | -3.0575e-06 | 1.2e-07 | -3.0425e-06 | 0.00015903 |
| kernel_target | 0.0003 | -8.6836e-06 | 3.6e-07 | -9.1275e-06 | 0.00015831 |
| kernel_target | 0.001 | -2.3367e-05 | 9.9e-07 | -3.0425e-05 | 0.00015306 |
| joint_sinkhorn | 0.0001 | -4.7131e-06 | 2.2e-07 | -4.486e-06 | 0.00015783 |
| joint_sinkhorn | 0.0003 | -1.3093e-05 | 6.4e-07 | -1.3458e-05 | 0.00015402 |
| joint_sinkhorn | 0.001 | -3.2546e-05 | 1.7e-06 | -4.486e-05 | 0.00014615 |
| fiber_sinkhorn | 0.0001 | -3.8176e-06 | 2.1e-07 | -3.9277e-06 | 0.00015688 |
| fiber_sinkhorn | 0.0003 | -1.0725e-05 | 6e-07 | -1.1783e-05 | 0.00015378 |
| fiber_sinkhorn | 0.001 | -2.7529e-05 | 1.8e-06 | -3.9277e-05 | 0.00015163 |
| wgan | 0.0001 | 4.8831e-08 | 2.3e-07 | -4.6422e-07 | 0.00015903 |
| wgan | 0.0003 | 1.6117e-06 | 7e-07 | -1.3927e-06 | 0.00016165 |
| wgan | 0.001 | 2.2157e-05 | 2.7e-06 | -4.6422e-06 | 0.00017047 |
| ddim10 | 0.0001 | -4.1263e-06 | 2.3e-07 | -4.2074e-06 | 0.00015712 |
| ddim10 | 0.0003 | -1.1101e-05 | 6.7e-07 | -1.2622e-05 | 0.00015569 |
| ddim10 | 0.001 | -2.3051e-05 | 2.1e-06 | -4.2074e-05 | 0.00015187 |
| ddim100 | 0.0001 | -7.6073e-06 | 3.2e-07 | -7.6693e-06 | 0.0001564 |
| ddim100 | 0.0003 | -2.2e-05 | 9.4e-07 | -2.3008e-05 | 0.00015092 |
| ddim100 | 0.001 | -6.4469e-05 | 2.8e-06 | -7.6693e-05 | 0.00013924 |
| fiber_full | 0.0001 | -4.8356e-07 | 9.5e-08 | -5.2418e-07 | 0.00015998 |
| fiber_full | 0.0003 | -4.8069e-07 | 2.7e-07 | -1.5726e-06 | 0.00016165 |
| fiber_full | 0.001 | 1.0193e-05 | 9.4e-07 | -5.2418e-06 | 0.00016546 |
