# Pathwise and finite-difference channel metrics

Fixed empirical distributions with common random numbers across perturbations.
Analytic rows are independent sampling floors, not subtracted from scores.
Moment features: y/sqrt(d) and vec(yy^T)/d. Augmented kernel is their direct sum with RBF.
Means below average anchors and MC repeats; neither establishes population suprema.

| Channel | Model | Estimator | h | RBF value | RBF derivative | Moment value | Moment derivative | Augmented derivative |
|---|---|---|---:|---:|---:|---:|---:|---:|
| SSPA | analytic | pathwise | 0.0 | 0.0467927 | 0.35605 | 0.0253049 | 0.021949 | 0.356775 |
| SSPA | kernel_target | pathwise | 0.0 | 0.704918 | 3.32018 | 0.4142 | 1.0643 | 3.46658 |
| SSPA | joint_sinkhorn | pathwise | 0.0 | 0.707886 | 3.05797 | 0.553268 | 1.15613 | 3.23123 |
| SSPA | fiber_sinkhorn | pathwise | 0.0 | 0.110993 | 0.668272 | 0.0622972 | 0.282958 | 0.712369 |
| SSPA | wgan | pathwise | 0.0 | 0.147399 | 0.961725 | 0.121202 | 0.314369 | 1.00178 |
| SSPA | ddim10 | pathwise | 0.0 | 0.151977 | 1.1697 | 0.0439844 | 0.224478 | 1.17781 |
| SSPA | ddim100 | pathwise | 0.0 | 0.0619376 | 0.48961 | 0.0429372 | 0.221414 | 0.52865 |
| SSPA | fiber_full | pathwise | 0.0 | 0.404283 | 1.9541 | 8.2372 | 5.01522 | 5.23602 |
