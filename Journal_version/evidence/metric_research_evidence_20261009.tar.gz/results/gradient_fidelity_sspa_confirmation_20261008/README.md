# Local gradient-fidelity pilot

Existing checkpoint seed only. Independent Monte Carlo repeats are not training seeds.
All methods use the same frozen codec within each comparison. Gradients are expected
cross-entropy gradients, not samplewise Jacobian comparisons between different latent draws.
Full-alphabet centering and unit RMS replace minibatch power normalization for this test.
Noise stays fixed under perturbations. These are not reruns of the paper's SER protocol.

## SSPA/analytic

Analytic-channel baseline CE: 0.0002627; SER: 4.92334e-05.

| Model | Conditional SWD | Global SWD at codewords | Input gradient cosine | Encoder gradient cosine | Encoder norm ratio | Relative input-gradient error |
|---|---:|---:|---:|---:|---:|---:|
| analytic | 0.0065618 | 0.0017041 | 0.9836 | 0.9982 | 1 | 0.183 |
| fiber_sinkhorn | 0.027905 | 0.010236 | 0.7200 | 0.8522 | 0.531 | 0.703 |
| wgan | 0.087596 | 0.081063 | 0.2953 | 0.2274 | 3.13 | 3.14 |
| ddim10 | 0.048654 | 0.013995 | 0.8282 | 0.9560 | 0.0482 | 0.956 |
| ddim100 | 0.011807 | 0.0042386 | 0.9671 | 0.9948 | 0.872 | 0.273 |
| fiber_full | 1.8322 | 1.6021 | 0.1036 | 0.7042 | 2.27e+03 | 2.79e+03 |

Analytic row is an independent, equal-sample Monte Carlo gradient and SWD floor.
Reference gradients use more samples; uncertainty and repeat-level values are in JSON.

### Single Encoder Steps on the Analytic Channel

Decoder frozen; normalized parameter steps, followed by full-codebook normalization.
Step normalization isolates direction and does not test the effect of erroneous gradient magnitudes.
Paired common-noise evaluation is independent of gradient estimation.
CE delta uncertainty is Monte Carlo SE across repeats, not training-seed variability.

| Model | Relative parameter step | Analytic CE delta | MC SE | First-order prediction | SER after step |
|---|---:|---:|---:|---:|---:|
| analytic | 0.0001 | -6.7114e-06 | 7.2e-08 | -6.8001e-06 | 4.6968e-05 |
| analytic | 0.0003 | -1.8084e-05 | 2.2e-07 | -2.04e-05 | 4.2796e-05 |
| analytic | 0.001 | -3.8953e-05 | 7.3e-07 | -6.8001e-05 | 3.6597e-05 |
| fiber_sinkhorn | 0.0001 | -5.7456e-06 | 5.5e-08 | -5.8056e-06 | 4.6968e-05 |
| fiber_sinkhorn | 0.0003 | -1.5372e-05 | 1.7e-07 | -1.7417e-05 | 4.518e-05 |
| fiber_sinkhorn | 0.001 | -3.1799e-05 | 6.1e-07 | -5.8056e-05 | 3.8743e-05 |
| wgan | 0.0001 | -1.5117e-06 | 8.8e-08 | -1.5495e-06 | 4.8161e-05 |
| wgan | 0.0003 | -3.0124e-06 | 2.6e-07 | -4.6484e-06 | 4.7684e-05 |
| wgan | 0.001 | 7.2814e-06 | 8.6e-07 | -1.5495e-05 | 4.9829e-05 |
| ddim10 | 0.0001 | -6.4055e-06 | 6.7e-08 | -6.5125e-06 | 4.6849e-05 |
| ddim10 | 0.0003 | -1.7204e-05 | 2.1e-07 | -1.9538e-05 | 4.2915e-05 |
| ddim10 | 0.001 | -3.6421e-05 | 7.2e-07 | -6.5125e-05 | 3.8028e-05 |
| ddim100 | 0.0001 | -6.6985e-06 | 6.9e-08 | -6.7768e-06 | 4.6968e-05 |
| ddim100 | 0.0003 | -1.8118e-05 | 2.1e-07 | -2.033e-05 | 4.2796e-05 |
| ddim100 | 0.001 | -3.9818e-05 | 6.9e-07 | -6.7768e-05 | 3.6597e-05 |
| fiber_full | 0.0001 | -4.6929e-06 | 5.7e-08 | -4.7971e-06 | 4.7922e-05 |
| fiber_full | 0.0003 | -1.2598e-05 | 1.8e-07 | -1.4391e-05 | 4.5061e-05 |
| fiber_full | 0.001 | -2.6069e-05 | 6.3e-07 | -4.7971e-05 | 4.077e-05 |

## SSPA/fiber_sinkhorn

Analytic-channel baseline CE: 0.000532966; SER: 0.000161171.

| Model | Conditional SWD | Global SWD at codewords | Input gradient cosine | Encoder gradient cosine | Encoder norm ratio | Relative input-gradient error |
|---|---:|---:|---:|---:|---:|---:|
| analytic | 0.0065618 | 0.0017337 | 0.9925 | 0.9931 | 0.983 | 0.125 |
| fiber_sinkhorn | 0.028748 | 0.0095441 | 0.4113 | 0.6245 | 0.128 | 0.955 |
| wgan | 0.088796 | 0.081528 | 0.3647 | 0.0172 | 3.91 | 2.39 |
| ddim10 | 0.048498 | 0.014582 | 0.8539 | 0.7244 | 0.0452 | 0.959 |
| ddim100 | 0.011076 | 0.0041211 | 0.9743 | 0.9754 | 0.831 | 0.245 |
| fiber_full | 1.8677 | 1.6383 | 0.0484 | 0.0587 | 2.55e+03 | 1.13e+03 |

Analytic row is an independent, equal-sample Monte Carlo gradient and SWD floor.
Reference gradients use more samples; uncertainty and repeat-level values are in JSON.

### Single Encoder Steps on the Analytic Channel

Decoder frozen; normalized parameter steps, followed by full-codebook normalization.
Step normalization isolates direction and does not test the effect of erroneous gradient magnitudes.
Paired common-noise evaluation is independent of gradient estimation.
CE delta uncertainty is Monte Carlo SE across repeats, not training-seed variability.

| Model | Relative parameter step | Analytic CE delta | MC SE | First-order prediction | SER after step |
|---|---:|---:|---:|---:|---:|
| analytic | 0.0001 | -7.8798e-06 | 1.2e-07 | -7.8916e-06 | 0.00015867 |
| analytic | 0.0003 | -2.2898e-05 | 3.6e-07 | -2.3675e-05 | 0.00015426 |
| analytic | 0.001 | -6.8322e-05 | 1.1e-06 | -7.8916e-05 | 0.00013947 |
| fiber_sinkhorn | 0.0001 | -5.0491e-06 | 1.2e-07 | -4.9626e-06 | 0.00015926 |
| fiber_sinkhorn | 0.0003 | -1.4472e-05 | 3.4e-07 | -1.4888e-05 | 0.00015616 |
| fiber_sinkhorn | 0.001 | -4.0789e-05 | 1e-06 | -4.9626e-05 | 0.00014806 |
| wgan | 0.0001 | 4.5727e-08 | 2.9e-07 | -1.3629e-07 | 0.00016201 |
| wgan | 0.0003 | 1.5943e-06 | 8.9e-07 | -4.0886e-07 | 0.00016391 |
| wgan | 0.001 | 2.199e-05 | 3.2e-06 | -1.3629e-06 | 0.00017071 |
| ddim10 | 0.0001 | -5.8569e-06 | 1.5e-07 | -5.7565e-06 | 0.00015938 |
| ddim10 | 0.0003 | -1.6598e-05 | 4.5e-07 | -1.727e-05 | 0.00015652 |
| ddim10 | 0.001 | -4.476e-05 | 1.4e-06 | -5.7565e-05 | 0.00014591 |
| ddim100 | 0.0001 | -7.7784e-06 | 1e-07 | -7.751e-06 | 0.00015855 |
| ddim100 | 0.0003 | -2.2619e-05 | 3.1e-07 | -2.3253e-05 | 0.00015402 |
| ddim100 | 0.001 | -6.7662e-05 | 9.8e-07 | -7.751e-05 | 0.00013983 |
| fiber_full | 0.0001 | -4.6072e-07 | 1.2e-07 | -4.6674e-07 | 0.00016105 |
| fiber_full | 0.0003 | -4.2215e-07 | 3.4e-07 | -1.4002e-06 | 0.00016201 |
| fiber_full | 0.001 | 1.0269e-05 | 8.2e-07 | -4.6674e-06 | 0.00016475 |
