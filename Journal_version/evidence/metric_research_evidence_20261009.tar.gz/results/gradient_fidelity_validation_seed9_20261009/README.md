# Local gradient-fidelity pilot

Existing checkpoint seed only. Independent Monte Carlo repeats are not training seeds.
All methods use the same frozen codec within each comparison. Gradients are expected
cross-entropy gradients, not samplewise Jacobian comparisons between different latent draws.
Full-alphabet centering and unit RMS replace minibatch power normalization for this test.
Noise stays fixed under perturbations. These are not reruns of the paper's SER protocol.

## SSPA/analytic

Analytic-channel baseline CE: 4.56924e-05; SER: 1.04904e-05.

| Model | Conditional SWD | Global SWD at codewords | Input gradient cosine | Encoder gradient cosine | Encoder norm ratio | Relative input-gradient error |
|---|---:|---:|---:|---:|---:|---:|
| analytic | 0.012925 | 0.0034255 | 0.6819 | 0.8744 | 1.19 | 0.929 |
| kernel_target | 0.20064 | 0.12163 | -0.0125 | 0.0341 | 0.000701 | 1 |
| joint_sinkhorn | 0.19792 | 0.13136 | -0.0014 | 0.2402 | 0.000932 | 1 |
| fiber_sinkhorn | 0.02813 | 0.0098676 | 0.3630 | 0.3905 | 0.764 | 1.1 |
| wgan | 0.044526 | 0.034564 | 0.2911 | 0.4344 | 0.46 | 0.995 |
| ddim10 | 0.049008 | 0.015602 | 0.6495 | 0.8927 | 0.0151 | 0.99 |
| ddim100 | 0.015903 | 0.005215 | 0.6485 | 0.8647 | 0.989 | 0.863 |
| fiber_full | 1.7524 | 1.4966 | 0.0463 | 0.1605 | 3.65e+04 | 2.17e+04 |

Analytic row is an independent, equal-sample Monte Carlo gradient and SWD floor.
Reference gradients use more samples; uncertainty and repeat-level values are in JSON.

### Single Encoder Steps on the Analytic Channel

Decoder frozen; normalized parameter steps, followed by full-codebook normalization.
Step normalization isolates direction and does not test the effect of erroneous gradient magnitudes.
Paired common-noise evaluation is independent of gradient estimation.
CE delta uncertainty is Monte Carlo SE across repeats, not training-seed variability.

| Model | Relative parameter step | Analytic CE delta | MC SE | First-order prediction | SER after step |
|---|---:|---:|---:|---:|---:|
| analytic | 0.0001 | -5.6791e-07 | 4.1e-08 | -6.251e-07 | 1.0729e-05 |
| analytic | 0.0003 | -1.5859e-06 | 1.2e-07 | -1.8753e-06 | 1.0252e-05 |
| analytic | 0.001 | -4.0086e-06 | 3.5e-07 | -6.251e-06 | 1.0252e-05 |
| kernel_target | 0.0001 | -2.6694e-08 | 6.6e-08 | -2.4399e-08 | 1.1206e-05 |
| kernel_target | 0.0003 | 1.9562e-08 | 1.9e-07 | -7.3198e-08 | 1.1444e-05 |
| kernel_target | 0.001 | 1.2335e-06 | 6.2e-07 | -2.4399e-07 | 1.0967e-05 |
| joint_sinkhorn | 0.0001 | -1.9285e-07 | 5.3e-08 | -1.7173e-07 | 1.0729e-05 |
| joint_sinkhorn | 0.0003 | -5.0598e-07 | 1.6e-07 | -5.1519e-07 | 1.1206e-05 |
| joint_sinkhorn | 0.001 | -8.6666e-07 | 5e-07 | -1.7173e-06 | 1.0967e-05 |
| fiber_sinkhorn | 0.0001 | -2.8146e-07 | 5.3e-08 | -2.7917e-07 | 1.049e-05 |
| fiber_sinkhorn | 0.0003 | -7.3246e-07 | 1.6e-07 | -8.3752e-07 | 1.049e-05 |
| fiber_sinkhorn | 0.001 | -1.2099e-06 | 5.2e-07 | -2.7917e-06 | 9.7752e-06 |
| wgan | 0.0001 | -2.3722e-07 | 5e-08 | -3.1055e-07 | 1.049e-05 |
| wgan | 0.0003 | -5.9229e-07 | 1.5e-07 | -9.3164e-07 | 1.0252e-05 |
| wgan | 0.001 | -6.3167e-07 | 4.5e-07 | -3.1055e-06 | 1.1444e-05 |
| ddim10 | 0.0001 | -6.307e-07 | 5.6e-08 | -6.3821e-07 | 1.049e-05 |
| ddim10 | 0.0003 | -1.7824e-06 | 1.6e-07 | -1.9146e-06 | 1.0252e-05 |
| ddim10 | 0.001 | -4.7643e-06 | 5e-07 | -6.3821e-06 | 9.7752e-06 |
| ddim100 | 0.0001 | -5.8127e-07 | 4.8e-08 | -6.1819e-07 | 1.049e-05 |
| ddim100 | 0.0003 | -1.6235e-06 | 1.4e-07 | -1.8546e-06 | 1.0252e-05 |
| ddim100 | 0.001 | -4.1108e-06 | 4.1e-07 | -6.1819e-06 | 9.7752e-06 |
| fiber_full | 0.0001 | -1.0278e-07 | 3.2e-08 | -1.1476e-07 | 1.0967e-05 |
| fiber_full | 0.0003 | -1.9101e-07 | 9.7e-08 | -3.4427e-07 | 1.1921e-05 |
| fiber_full | 0.001 | 6.7434e-07 | 3.5e-07 | -1.1476e-06 | 1.2159e-05 |

## SSPA/fiber_sinkhorn

Analytic-channel baseline CE: 0.000533433; SER: 0.000168324.

| Model | Conditional SWD | Global SWD at codewords | Input gradient cosine | Encoder gradient cosine | Encoder norm ratio | Relative input-gradient error |
|---|---:|---:|---:|---:|---:|---:|
| analytic | 0.012925 | 0.0034234 | 0.9627 | 0.9717 | 0.91 | 0.274 |
| kernel_target | 0.19414 | 0.10519 | 0.1984 | 0.1721 | 0.000119 | 1 |
| joint_sinkhorn | 0.18934 | 0.10701 | 0.3015 | 0.1626 | 175 | 255 |
| fiber_sinkhorn | 0.032814 | 0.010688 | 0.4187 | 0.4801 | 0.0508 | 0.978 |
| wgan | 0.044765 | 0.034089 | 0.6950 | 0.8573 | 0.468 | 0.769 |
| ddim10 | 0.049246 | 0.014541 | 0.8144 | 0.7642 | 0.0395 | 0.953 |
| ddim100 | 0.016276 | 0.0048003 | 0.9458 | 0.9759 | 0.834 | 0.327 |
| fiber_full | 1.689 | 1.4284 | 0.0020 | -0.2647 | 4.12e+03 | 1.62e+03 |

Analytic row is an independent, equal-sample Monte Carlo gradient and SWD floor.
Reference gradients use more samples; uncertainty and repeat-level values are in JSON.

### Single Encoder Steps on the Analytic Channel

Decoder frozen; normalized parameter steps, followed by full-codebook normalization.
Step normalization isolates direction and does not test the effect of erroneous gradient magnitudes.
Paired common-noise evaluation is independent of gradient estimation.
CE delta uncertainty is Monte Carlo SE across repeats, not training-seed variability.

| Model | Relative parameter step | Analytic CE delta | MC SE | First-order prediction | SER after step |
|---|---:|---:|---:|---:|---:|
| analytic | 0.0001 | -8.8159e-06 | 2.3e-07 | -9.0789e-06 | 0.00016618 |
| analytic | 0.0003 | -2.5009e-05 | 6.6e-07 | -2.7237e-05 | 0.00016308 |
| analytic | 0.001 | -6.7786e-05 | 1.9e-06 | -9.0789e-05 | 0.00014496 |
| kernel_target | 0.0001 | -1.4732e-06 | 1.7e-07 | -1.6077e-06 | 0.00016832 |
| kernel_target | 0.0003 | -3.77e-06 | 5e-07 | -4.8232e-06 | 0.00016832 |
| kernel_target | 0.001 | -5.0228e-06 | 1.7e-06 | -1.6077e-05 | 0.00016594 |
| joint_sinkhorn | 0.0001 | -1.4217e-06 | 8.8e-08 | -1.5194e-06 | 0.00016618 |
| joint_sinkhorn | 0.0003 | -3.6033e-06 | 2.6e-07 | -4.5582e-06 | 0.00016689 |
| joint_sinkhorn | 0.001 | -5.025e-06 | 8.4e-07 | -1.5194e-05 | 0.00016665 |
| fiber_sinkhorn | 0.0001 | -4.3693e-06 | 6.5e-08 | -4.486e-06 | 0.00016594 |
| fiber_sinkhorn | 0.0003 | -1.1763e-05 | 2e-07 | -1.3458e-05 | 0.00016403 |
| fiber_sinkhorn | 0.001 | -2.4577e-05 | 7.1e-07 | -4.486e-05 | 0.00015831 |
| wgan | 0.0001 | -7.5022e-06 | 1.3e-07 | -8.0105e-06 | 0.00016594 |
| wgan | 0.0003 | -2.0784e-05 | 3.7e-07 | -2.4032e-05 | 0.00016308 |
| wgan | 0.001 | -5.0553e-05 | 8.8e-07 | -8.0105e-05 | 0.00015306 |
| ddim10 | 0.0001 | -6.9419e-06 | 9.4e-08 | -7.14e-06 | 0.00016665 |
| ddim10 | 0.0003 | -1.9837e-05 | 2.7e-07 | -2.142e-05 | 0.00016379 |
| ddim10 | 0.001 | -5.5475e-05 | 7.2e-07 | -7.14e-05 | 0.00015235 |
| ddim100 | 0.0001 | -8.7282e-06 | 1.7e-07 | -9.1185e-06 | 0.00016594 |
| ddim100 | 0.0003 | -2.4577e-05 | 4.7e-07 | -2.7355e-05 | 0.00016212 |
| ddim100 | 0.001 | -6.4669e-05 | 1.2e-06 | -9.1185e-05 | 0.00014687 |
| fiber_full | 0.0001 | 2.5961e-06 | 1.4e-07 | 2.4729e-06 | 0.00016809 |
| fiber_full | 0.0003 | 8.5278e-06 | 4.2e-07 | 7.4186e-06 | 0.00016928 |
| fiber_full | 0.001 | 3.744e-05 | 1.4e-06 | 2.4729e-05 | 0.00017643 |
