"""Sample-only conditional embedding values and finite input derivatives.

These are finite-panel estimates, not bounds on a population input supremum.
"""

import torch


def perturbed_inputs(x, step):
    if step <= 0:
        raise ValueError("The difference step must be positive.")
    eye = torch.eye(x.numel(), dtype=x.dtype, device=x.device) * step
    pairs = torch.stack((x + eye, x - eye), dim=1).flatten(0, 1)
    return torch.cat((x[None], pairs))


def difference_weights(dimension, step, device=None):
    """Columns represent base value and each centered derivative of P-Q."""
    queries = 1 + 2 * dimension
    weights = torch.zeros(2 * queries, dimension + 1, dtype=torch.float64, device=device)
    weights[0, 0], weights[queries, 0] = 1, -1
    for j in range(dimension):
        plus, minus = 1 + 2 * j, 2 + 2 * j
        weights[plus, j + 1] = weights[queries + minus, j + 1] = 1 / (2 * step)
        weights[minus, j + 1] = weights[queries + plus, j + 1] = -1 / (2 * step)
    return weights


def empirical_embedding_gram(clouds, bandwidths, groups_per_block=2):
    """Full RBF kernels, averaged across bandwidths, retaining V-statistic diagonals."""
    if clouds.ndim != 3 or clouds.shape[1] < 2:
        raise ValueError("Expected [cloud, samples>=2, output coordinate].")
    if not bandwidths or min(bandwidths) <= 0 or groups_per_block < 1:
        raise ValueError("Positive bandwidths and block size required.")
    clouds = clouds.double()
    groups, samples, dim = clouds.shape
    flat = clouds.reshape(-1, dim)
    norm = flat.square().sum(-1)
    gram = torch.empty(groups, groups, dtype=clouds.dtype, device=clouds.device)
    for start in range(0, groups, groups_per_block):
        count = min(groups_per_block, groups - start)
        rows = flat[start * samples:(start + count) * samples]
        distances = (rows.square().sum(-1, keepdim=True) + norm[None] - 2 * rows @ flat.T).clamp_min(0)
        block = torch.zeros_like(distances)
        for bandwidth in bandwidths:
            block += torch.exp(-distances / (2 * bandwidth**2)) / len(bandwidths)
        gram[start:start + count] = block.reshape(count, samples, groups, samples).mean(dim=(1, 3))
    return (gram + gram.T) / 2


def gaussian_embedding_gram(means, variances, bandwidths):
    """Exact RBF embedding inner products for isotropic Gaussian laws (zero variance allowed)."""
    means = means.double()
    variances = torch.as_tensor(variances, dtype=means.dtype, device=means.device).expand(len(means))
    if (variances < 0).any() or not bandwidths or min(bandwidths) <= 0:
        raise ValueError("Variances must be nonnegative and bandwidths positive.")
    distance = (means[:, None] - means[None]).square().sum(-1)
    gram = torch.zeros_like(distance)
    for bandwidth in bandwidths:
        total = bandwidth**2 + variances[:, None] + variances[None]
        gram += (bandwidth**2 / total).pow(means.shape[-1] / 2) * torch.exp(-distance / (2 * total)) / len(bandwidths)
    return gram


def embedding_scores(gram, dimension, step):
    weights = difference_weights(dimension, step, gram.device)
    if gram.shape != (len(weights), len(weights)):
        raise ValueError("Gram matrix does not match the perturbation layout.")
    matrix = weights.T @ gram.double() @ weights
    matrix = (matrix + matrix.T) / 2
    eigenvalues = torch.linalg.eigvalsh(matrix[1:, 1:])
    tolerance = 1e-7 * max(1., matrix.abs().max().item())
    if matrix[0, 0] < -tolerance or eigenvalues[0] < -tolerance:
        raise ValueError("Embedding Gram matrix lost positive semidefiniteness.")
    return {
        "mmd": matrix[0, 0].clamp_min(0).sqrt().item(),
        "embedding_derivative_op": eigenvalues[-1].clamp_min(0).sqrt().item(),
        "embedding_derivative_fro": matrix[1:, 1:].trace().clamp_min(0).sqrt().item(),
        "derivative_gram_min_eigenvalue": eigenvalues[0].item(),
    }


def moment_scores(p, q, dimension, step):
    p, q = p.double(), q.double()
    means = p.mean(1) - q.mean(1)
    def covariance(cloud):
        centered = cloud - cloud.mean(1, keepdim=True)
        return centered.transpose(1, 2) @ centered / (cloud.shape[1] - 1)
    cov = covariance(p) - covariance(q)
    def derivatives(values):
        return ((values[1::2] - values[2::2]) / (2 * step)).reshape(dimension, -1).T
    return {
        "mean_l2": means[0].norm().item(),
        "covariance_fro": cov[0].norm().item(),
        "mean_derivative_op": torch.linalg.matrix_norm(derivatives(means), ord=2).item(),
        "covariance_derivative_op": torch.linalg.matrix_norm(derivatives(cov), ord=2).item(),
    }
