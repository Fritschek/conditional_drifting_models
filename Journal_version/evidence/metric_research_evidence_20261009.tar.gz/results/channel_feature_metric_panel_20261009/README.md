# Decoder-free feature metric pilot

Development seed only; no downstream codec is loaded to calculate a score.
Full RBF-kernel empirical embedding norms (V-statistics), not random features.
Analytic row is an independent exact-channel sampling floor, not a subtraction.
CRN shares noise across input perturbations within a simulator; independent mode does not.
Bandwidths are fixed from physical noise, not tuned against downstream results.
Table entries average fixed anchors and Monte Carlo repeats; maxima and MC SE are in JSON.
Finite-panel maxima do not certify population suprema. Historical training budgets differ.

| Channel | Model | Noise pairing | h | SWD | MMD | Embedding derivative | Mean derivative | Covariance derivative |
|---|---|---|---:|---:|---:|---:|---:|---:|
| AWGN | analytic | crn | 0.025 | 0.084126 | 0.096504 | 0.13087 | 1.2594e-07 | 3.2138e-07 |
| AWGN | analytic | crn | 0.05 | 0.084126 | 0.096504 | 0.13067 | 8.2795e-08 | 1.7802e-07 |
| AWGN | analytic | crn | 0.1 | 0.084126 | 0.096504 | 0.12986 | 3.2943e-08 | 7.8092e-08 |
| AWGN | analytic | independent | 0.025 | 0.084126 | 0.096504 | 3.6163 | 8.509 | 10.052 |
| AWGN | analytic | independent | 0.05 | 0.084126 | 0.096504 | 1.8078 | 4.2545 | 5.0261 |
| AWGN | analytic | independent | 0.1 | 0.084126 | 0.096504 | 0.90333 | 2.1272 | 2.5131 |
| AWGN | kernel_target | crn | 0.025 | 0.37917 | 0.54229 | 0.95266 | 0.22778 | 0.0049858 |
| AWGN | kernel_target | crn | 0.05 | 0.37917 | 0.54229 | 0.95028 | 0.22778 | 0.0049857 |
| AWGN | kernel_target | crn | 0.1 | 0.37917 | 0.54229 | 0.94085 | 0.22781 | 0.0049853 |
| AWGN | kernel_target | independent | 0.025 | 0.37917 | 0.54229 | 2.9254 | 6.1905 | 7.1531 |
| AWGN | kernel_target | independent | 0.05 | 0.37917 | 0.54229 | 1.7251 | 3.1088 | 3.5766 |
| AWGN | kernel_target | independent | 0.1 | 0.37917 | 0.54229 | 1.2085 | 1.5756 | 1.7884 |
| AWGN | joint_sinkhorn | crn | 0.025 | 0.08952 | 0.10687 | 0.15788 | 0.12613 | 0.053011 |
| AWGN | joint_sinkhorn | crn | 0.05 | 0.08952 | 0.10687 | 0.15764 | 0.12613 | 0.053009 |
| AWGN | joint_sinkhorn | crn | 0.1 | 0.08952 | 0.10687 | 0.15671 | 0.12612 | 0.052999 |
| AWGN | joint_sinkhorn | independent | 0.025 | 0.08952 | 0.10687 | 3.5878 | 8.1735 | 9.401 |
| AWGN | joint_sinkhorn | independent | 0.05 | 0.08952 | 0.10687 | 1.795 | 4.088 | 4.7012 |
| AWGN | joint_sinkhorn | independent | 0.1 | 0.08952 | 0.10687 | 0.89951 | 2.0464 | 2.3515 |
| AWGN | fiber_sinkhorn | crn | 0.025 | 0.082527 | 0.094485 | 0.12831 | 0.02946 | 0.024048 |
| AWGN | fiber_sinkhorn | crn | 0.05 | 0.082527 | 0.094485 | 0.12811 | 0.02946 | 0.024048 |
| AWGN | fiber_sinkhorn | crn | 0.1 | 0.082527 | 0.094485 | 0.12729 | 0.029459 | 0.024045 |
| AWGN | fiber_sinkhorn | independent | 0.025 | 0.082527 | 0.094485 | 3.6458 | 8.8167 | 9.8685 |
| AWGN | fiber_sinkhorn | independent | 0.05 | 0.082527 | 0.094485 | 1.8227 | 4.4083 | 4.9345 |
| AWGN | fiber_sinkhorn | independent | 0.1 | 0.082527 | 0.094485 | 0.91088 | 2.2042 | 2.4675 |
| AWGN | wgan | crn | 0.025 | 0.087811 | 0.10076 | 0.13677 | 0.06642 | 0.065045 |
| AWGN | wgan | crn | 0.05 | 0.087811 | 0.10076 | 0.13656 | 0.066388 | 0.065029 |
| AWGN | wgan | crn | 0.1 | 0.087811 | 0.10076 | 0.13568 | 0.066178 | 0.06473 |
| AWGN | wgan | independent | 0.025 | 0.087811 | 0.10076 | 3.5369 | 8.3128 | 10.08 |
| AWGN | wgan | independent | 0.05 | 0.087811 | 0.10076 | 1.7694 | 4.1566 | 5.0399 |
| AWGN | wgan | independent | 0.1 | 0.087811 | 0.10076 | 0.88564 | 2.0788 | 2.52 |
| AWGN | ddim10 | crn | 0.025 | 0.094685 | 0.11906 | 0.1618 | 0.011124 | 0.0039876 |
| AWGN | ddim10 | crn | 0.05 | 0.094685 | 0.11906 | 0.16156 | 0.011124 | 0.0039875 |
| AWGN | ddim10 | crn | 0.1 | 0.094685 | 0.11906 | 0.16062 | 0.011122 | 0.0039865 |
| AWGN | ddim10 | independent | 0.025 | 0.094685 | 0.11906 | 3.5536 | 7.9656 | 8.8128 |
| AWGN | ddim10 | independent | 0.05 | 0.094685 | 0.11906 | 1.7783 | 3.9826 | 4.4065 |
| AWGN | ddim10 | independent | 0.1 | 0.094685 | 0.11906 | 0.89312 | 1.9911 | 2.2033 |
| AWGN | ddim100 | crn | 0.025 | 0.084245 | 0.097098 | 0.13202 | 0.0096064 | 0.0039528 |
| AWGN | ddim100 | crn | 0.05 | 0.084245 | 0.097098 | 0.13181 | 0.0096059 | 0.0039525 |
| AWGN | ddim100 | crn | 0.1 | 0.084245 | 0.097098 | 0.131 | 0.0096044 | 0.0039515 |
| AWGN | ddim100 | independent | 0.025 | 0.084245 | 0.097098 | 3.61 | 8.4512 | 9.9106 |
| AWGN | ddim100 | independent | 0.05 | 0.084245 | 0.097098 | 1.8047 | 4.2253 | 4.9554 |
| AWGN | ddim100 | independent | 0.1 | 0.084245 | 0.097098 | 0.90171 | 2.1124 | 2.4778 |
| SSPA | analytic | crn | 0.025 | 0.036245 | 0.094593 | 0.69284 | 1.8221e-07 | 1.6706e-07 |
| SSPA | analytic | crn | 0.05 | 0.036245 | 0.094593 | 0.63039 | 9.3708e-08 | 8.2048e-08 |
| SSPA | analytic | crn | 0.1 | 0.036245 | 0.094593 | 0.49395 | 4.9889e-08 | 4.4726e-08 |
| SSPA | analytic | independent | 0.025 | 0.036245 | 0.094593 | 3.6715 | 4.02 | 2.2069 |
| SSPA | analytic | independent | 0.05 | 0.036245 | 0.094593 | 1.8351 | 2.01 | 1.1035 |
| SSPA | analytic | independent | 0.1 | 0.036245 | 0.094593 | 0.91215 | 1.005 | 0.55173 |
| SSPA | kernel_target | crn | 0.025 | 0.22234 | 0.69655 | 3.4464 | 1.5567 | 0.0080823 |
| SSPA | kernel_target | crn | 0.05 | 0.22234 | 0.69655 | 3.3352 | 1.5497 | 0.0080662 |
| SSPA | kernel_target | crn | 0.1 | 0.22234 | 0.69655 | 2.9795 | 1.5212 | 0.0080026 |
| SSPA | kernel_target | independent | 0.025 | 0.22234 | 0.69655 | 4.3112 | 3.3347 | 1.516 |
| SSPA | kernel_target | independent | 0.05 | 0.22234 | 0.69655 | 3.5607 | 2.2256 | 0.75806 |
| SSPA | kernel_target | independent | 0.1 | 0.22234 | 0.69655 | 3.0236 | 1.7776 | 0.37914 |
| SSPA | joint_sinkhorn | crn | 0.025 | 0.2596 | 0.69962 | 3.0084 | 1.7865 | 0.036293 |
| SSPA | joint_sinkhorn | crn | 0.05 | 0.2596 | 0.69962 | 2.9209 | 1.7791 | 0.036241 |
| SSPA | joint_sinkhorn | crn | 0.1 | 0.2596 | 0.69962 | 2.6471 | 1.7496 | 0.036037 |
| SSPA | joint_sinkhorn | independent | 0.025 | 0.2596 | 0.69962 | 4.1999 | 3.6238 | 1.5316 |
| SSPA | joint_sinkhorn | independent | 0.05 | 0.2596 | 0.69962 | 3.2361 | 2.4457 | 0.76639 |
| SSPA | joint_sinkhorn | independent | 0.1 | 0.2596 | 0.69962 | 2.7165 | 1.9785 | 0.38408 |
| SSPA | fiber_sinkhorn | crn | 0.025 | 0.050113 | 0.13198 | 0.85319 | 0.41671 | 0.077978 |
| SSPA | fiber_sinkhorn | crn | 0.05 | 0.050113 | 0.13198 | 0.78572 | 0.40306 | 0.077462 |
| SSPA | fiber_sinkhorn | crn | 0.1 | 0.050113 | 0.13198 | 0.63359 | 0.35975 | 0.075463 |
| SSPA | fiber_sinkhorn | independent | 0.025 | 0.050113 | 0.13198 | 3.588 | 3.9089 | 2.1013 |
| SSPA | fiber_sinkhorn | independent | 0.05 | 0.050113 | 0.13198 | 1.8186 | 1.9802 | 1.0512 |
| SSPA | fiber_sinkhorn | independent | 0.1 | 0.050113 | 0.13198 | 0.94102 | 1.026 | 0.52706 |
| SSPA | wgan | crn | 0.025 | 0.10148 | 0.24192 | 1.3458 | 0.55256 | 0.31159 |
| SSPA | wgan | crn | 0.05 | 0.10148 | 0.24192 | 1.2699 | 0.54265 | 0.30555 |
| SSPA | wgan | crn | 0.1 | 0.10148 | 0.24192 | 1.0637 | 0.5197 | 0.28733 |
| SSPA | wgan | independent | 0.025 | 0.10148 | 0.24192 | 3.8325 | 4.4272 | 2.7026 |
| SSPA | wgan | independent | 0.05 | 0.10148 | 0.24192 | 2.1405 | 2.2729 | 1.3696 |
| SSPA | wgan | independent | 0.1 | 0.10148 | 0.24192 | 1.3026 | 1.2299 | 0.71978 |
| SSPA | ddim10 | crn | 0.025 | 0.056551 | 0.17233 | 1.3502 | 0.39719 | 0.0076637 |
| SSPA | ddim10 | crn | 0.05 | 0.056551 | 0.17233 | 1.232 | 0.3801 | 0.0075926 |
| SSPA | ddim10 | crn | 0.1 | 0.056551 | 0.17233 | 0.96212 | 0.31617 | 0.0073308 |
| SSPA | ddim10 | independent | 0.025 | 0.056551 | 0.17233 | 3.6695 | 3.5751 | 1.7729 |
| SSPA | ddim10 | independent | 0.05 | 0.056551 | 0.17233 | 2.0025 | 1.8077 | 0.88641 |
| SSPA | ddim10 | independent | 0.1 | 0.056551 | 0.17233 | 1.1582 | 0.92814 | 0.44321 |
| SSPA | ddim100 | crn | 0.025 | 0.038874 | 0.10119 | 0.77013 | 0.37564 | 0.0096342 |
| SSPA | ddim100 | crn | 0.05 | 0.038874 | 0.10119 | 0.69744 | 0.35906 | 0.009557 |
| SSPA | ddim100 | crn | 0.1 | 0.038874 | 0.10119 | 0.5379 | 0.29927 | 0.0092762 |
| SSPA | ddim100 | independent | 0.025 | 0.038874 | 0.10119 | 3.6782 | 4.0065 | 2.1791 |
| SSPA | ddim100 | independent | 0.05 | 0.038874 | 0.10119 | 1.8501 | 2.0213 | 1.0895 |
| SSPA | ddim100 | independent | 0.1 | 0.038874 | 0.10119 | 0.9264 | 1.0304 | 0.54474 |
| SSPA | fiber_full | crn | 0.025 | 1.7217 | 0.42514 | 1.9813 | 0.63754 | 42.644 |
| SSPA | fiber_full | crn | 0.05 | 1.7217 | 0.42514 | 1.8733 | 0.62873 | 42.629 |
| SSPA | fiber_full | crn | 0.1 | 1.7217 | 0.42514 | 1.6224 | 0.60567 | 42.568 |
| SSPA | fiber_full | independent | 0.025 | 1.7217 | 0.42514 | 4.285 | 59.761 | 2225 |
| SSPA | fiber_full | independent | 0.05 | 1.7217 | 0.42514 | 2.5979 | 29.877 | 1113.1 |
| SSPA | fiber_full | independent | 0.1 | 1.7217 | 0.42514 | 1.7869 | 14.935 | 557.68 |
