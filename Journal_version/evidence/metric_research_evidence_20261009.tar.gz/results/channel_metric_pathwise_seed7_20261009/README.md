# Pathwise and finite-difference channel metrics

Fixed empirical distributions with common random numbers across perturbations.
Analytic rows are independent sampling floors, not subtracted from scores.
Moment features: y/sqrt(d) and vec(yy^T)/d. Augmented kernel is their direct sum with RBF.
Means below average anchors and MC repeats; neither establishes population suprema.

| Channel | Model | Estimator | h | RBF value | RBF derivative | Moment value | Moment derivative | Augmented derivative |
|---|---|---|---:|---:|---:|---:|---:|---:|
| AWGN | analytic | pathwise | 0.0 | 0.0954517 | 0.128602 | 0.134949 | 0.0494437 | 0.137179 |
| AWGN | analytic | finite_difference | 0.05 | 0.0954517 | 0.128334 | 0.134949 | 0.0494436 | 0.136929 |
| AWGN | analytic | finite_difference | 0.0125 | 0.0954517 | 0.128585 | 0.134949 | 0.0494437 | 0.137164 |
| AWGN | analytic | finite_difference | 0.003125 | 0.0954517 | 0.128601 | 0.134949 | 0.0494434 | 0.137178 |
| AWGN | analytic | finite_difference | 0.00078125 | 0.0954517 | 0.128603 | 0.134949 | 0.0494446 | 0.137181 |
| AWGN | kernel_target | pathwise | 0.0 | 0.540437 | 0.951473 | 0.440845 | 0.350322 | 1.02666 |
| AWGN | kernel_target | finite_difference | 0.05 | 0.540437 | 0.948288 | 0.440845 | 0.350345 | 1.02372 |
| AWGN | kernel_target | finite_difference | 0.0125 | 0.540437 | 0.951275 | 0.440845 | 0.350324 | 1.02648 |
| AWGN | kernel_target | finite_difference | 0.003125 | 0.540437 | 0.951456 | 0.440845 | 0.350321 | 1.02664 |
| AWGN | kernel_target | finite_difference | 0.00078125 | 0.540437 | 0.951506 | 0.440845 | 0.350346 | 1.0267 |
| AWGN | joint_sinkhorn | pathwise | 0.0 | 0.105948 | 0.154964 | 0.147258 | 0.148018 | 0.22037 |
| AWGN | joint_sinkhorn | finite_difference | 0.05 | 0.105948 | 0.154659 | 0.147258 | 0.148026 | 0.220151 |
| AWGN | joint_sinkhorn | finite_difference | 0.0125 | 0.105948 | 0.154945 | 0.147258 | 0.148019 | 0.220357 |
| AWGN | joint_sinkhorn | finite_difference | 0.003125 | 0.105948 | 0.154962 | 0.147258 | 0.148017 | 0.220368 |
| AWGN | joint_sinkhorn | finite_difference | 0.00078125 | 0.105948 | 0.154967 | 0.147258 | 0.148026 | 0.220379 |
| AWGN | fiber_sinkhorn | pathwise | 0.0 | 0.0946109 | 0.128335 | 0.125664 | 0.0536671 | 0.137437 |
| AWGN | fiber_sinkhorn | finite_difference | 0.05 | 0.0946109 | 0.128058 | 0.125664 | 0.0536675 | 0.137183 |
| AWGN | fiber_sinkhorn | finite_difference | 0.0125 | 0.0946109 | 0.128318 | 0.125664 | 0.0536672 | 0.137421 |
| AWGN | fiber_sinkhorn | finite_difference | 0.003125 | 0.0946109 | 0.128334 | 0.125664 | 0.0536667 | 0.137435 |
| AWGN | fiber_sinkhorn | finite_difference | 0.00078125 | 0.0946109 | 0.128336 | 0.125664 | 0.0536672 | 0.137438 |
| AWGN | wgan | pathwise | 0.0 | 0.099737 | 0.135345 | 0.14451 | 0.0792014 | 0.15463 |
| AWGN | wgan | finite_difference | 0.05 | 0.099737 | 0.13507 | 0.14451 | 0.0792373 | 0.15449 |
| AWGN | wgan | finite_difference | 0.0125 | 0.099737 | 0.135319 | 0.14451 | 0.079123 | 0.154616 |
| AWGN | wgan | finite_difference | 0.003125 | 0.099737 | 0.135328 | 0.14451 | 0.0791496 | 0.154616 |
| AWGN | wgan | finite_difference | 0.00078125 | 0.099737 | 0.135337 | 0.14451 | 0.0791676 | 0.154614 |
| AWGN | ddim10 | pathwise | 0.0 | 0.116863 | 0.159125 | 0.128699 | 0.0476488 | 0.164985 |
| AWGN | ddim10 | finite_difference | 0.05 | 0.116863 | 0.158813 | 0.128699 | 0.0476485 | 0.164686 |
| AWGN | ddim10 | finite_difference | 0.0125 | 0.116863 | 0.159105 | 0.128699 | 0.047649 | 0.164967 |
| AWGN | ddim10 | finite_difference | 0.003125 | 0.116863 | 0.159123 | 0.128699 | 0.0476489 | 0.164984 |
| AWGN | ddim10 | finite_difference | 0.00078125 | 0.116863 | 0.159126 | 0.128699 | 0.0476485 | 0.164988 |
| AWGN | ddim100 | pathwise | 0.0 | 0.0958296 | 0.129665 | 0.135716 | 0.0507419 | 0.138465 |
| AWGN | ddim100 | finite_difference | 0.05 | 0.0958296 | 0.129396 | 0.135716 | 0.0507417 | 0.138214 |
| AWGN | ddim100 | finite_difference | 0.0125 | 0.0958296 | 0.129649 | 0.135716 | 0.0507413 | 0.13845 |
| AWGN | ddim100 | finite_difference | 0.003125 | 0.0958296 | 0.129664 | 0.135716 | 0.0507406 | 0.138464 |
| AWGN | ddim100 | finite_difference | 0.00078125 | 0.0958296 | 0.129668 | 0.135716 | 0.0507473 | 0.138468 |
| SSPA | analytic | pathwise | 0.0 | 0.0939561 | 0.71027 | 0.0518057 | 0.0454035 | 0.711729 |
| SSPA | analytic | finite_difference | 0.05 | 0.0939561 | 0.62274 | 0.0518057 | 0.0452936 | 0.624382 |
| SSPA | analytic | finite_difference | 0.0125 | 0.0939561 | 0.703666 | 0.0518057 | 0.0453967 | 0.705136 |
| SSPA | analytic | finite_difference | 0.003125 | 0.0939561 | 0.709853 | 0.0518057 | 0.0454032 | 0.711312 |
| SSPA | analytic | finite_difference | 0.00078125 | 0.0939561 | 0.710241 | 0.0518057 | 0.0454033 | 0.711699 |
| SSPA | kernel_target | pathwise | 0.0 | 0.694982 | 3.47994 | 0.381224 | 1.04199 | 3.61249 |
| SSPA | kernel_target | finite_difference | 0.05 | 0.694982 | 3.32882 | 0.381224 | 1.03476 | 3.46465 |
| SSPA | kernel_target | finite_difference | 0.0125 | 0.694982 | 3.46981 | 0.381224 | 1.04154 | 3.6026 |
| SSPA | kernel_target | finite_difference | 0.003125 | 0.694982 | 3.47931 | 0.381224 | 1.04196 | 3.61187 |
| SSPA | kernel_target | finite_difference | 0.00078125 | 0.694982 | 3.47989 | 0.381224 | 1.04197 | 3.61244 |
| SSPA | joint_sinkhorn | pathwise | 0.0 | 0.699923 | 3.0288 | 0.529867 | 1.21327 | 3.24155 |
| SSPA | joint_sinkhorn | finite_difference | 0.05 | 0.699923 | 2.91053 | 0.529867 | 1.2042 | 3.12891 |
| SSPA | joint_sinkhorn | finite_difference | 0.0125 | 0.699923 | 3.02081 | 0.529867 | 1.21267 | 3.23393 |
| SSPA | joint_sinkhorn | finite_difference | 0.003125 | 0.699923 | 3.0283 | 0.529867 | 1.21322 | 3.24107 |
| SSPA | joint_sinkhorn | finite_difference | 0.00078125 | 0.699923 | 3.02878 | 0.529867 | 1.21325 | 3.24154 |
| SSPA | fiber_sinkhorn | pathwise | 0.0 | 0.133125 | 0.889899 | 0.086009 | 0.288278 | 0.907938 |
| SSPA | fiber_sinkhorn | finite_difference | 0.05 | 0.133125 | 0.794841 | 0.086009 | 0.27628 | 0.814473 |
| SSPA | fiber_sinkhorn | finite_difference | 0.0125 | 0.133125 | 0.882778 | 0.086009 | 0.28749 | 0.900931 |
| SSPA | fiber_sinkhorn | finite_difference | 0.003125 | 0.133125 | 0.889449 | 0.086009 | 0.288227 | 0.907495 |
| SSPA | fiber_sinkhorn | finite_difference | 0.00078125 | 0.133125 | 0.889866 | 0.086009 | 0.288276 | 0.907902 |
| SSPA | wgan | pathwise | 0.0 | 0.243624 | 1.37383 | 0.195608 | 0.391772 | 1.41786 |
| SSPA | wgan | finite_difference | 0.05 | 0.243624 | 1.26924 | 0.195608 | 0.382068 | 1.3166 |
| SSPA | wgan | finite_difference | 0.0125 | 0.243624 | 1.36665 | 0.195608 | 0.391713 | 1.41115 |
| SSPA | wgan | finite_difference | 0.003125 | 0.243624 | 1.37349 | 0.195608 | 0.392101 | 1.41757 |
| SSPA | wgan | finite_difference | 0.00078125 | 0.243624 | 1.37385 | 0.195608 | 0.391898 | 1.4179 |
| SSPA | ddim10 | pathwise | 0.0 | 0.171642 | 1.39242 | 0.0574476 | 0.253278 | 1.40507 |
| SSPA | ddim10 | finite_difference | 0.05 | 0.171642 | 1.22473 | 0.0574476 | 0.238994 | 1.23814 |
| SSPA | ddim10 | finite_difference | 0.0125 | 0.171642 | 1.3799 | 0.0574476 | 0.252368 | 1.39259 |
| SSPA | ddim10 | finite_difference | 0.003125 | 0.171642 | 1.39163 | 0.0574476 | 0.253221 | 1.40428 |
| SSPA | ddim10 | finite_difference | 0.00078125 | 0.171642 | 1.39238 | 0.0574476 | 0.253276 | 1.40502 |
| SSPA | ddim100 | pathwise | 0.0 | 0.101223 | 0.797392 | 0.0610251 | 0.24289 | 0.825983 |
| SSPA | ddim100 | finite_difference | 0.05 | 0.101223 | 0.695057 | 0.0610251 | 0.229349 | 0.725573 |
| SSPA | ddim100 | finite_difference | 0.0125 | 0.101223 | 0.789689 | 0.0610251 | 0.242023 | 0.81843 |
| SSPA | ddim100 | finite_difference | 0.003125 | 0.101223 | 0.796905 | 0.0610251 | 0.242837 | 0.825507 |
| SSPA | ddim100 | finite_difference | 0.00078125 | 0.101223 | 0.797361 | 0.0610251 | 0.242884 | 0.825952 |
| SSPA | fiber_full | pathwise | 0.0 | 0.42746 | 2.14522 | 7.92217 | 5.28362 | 5.60428 |
| SSPA | fiber_full | finite_difference | 0.05 | 0.42746 | 1.88612 | 7.92217 | 5.28327 | 5.49479 |
| SSPA | fiber_full | finite_difference | 0.0125 | 0.42746 | 2.05386 | 7.92217 | 5.2836 | 5.56902 |
| SSPA | fiber_full | finite_difference | 0.003125 | 0.42746 | 2.13006 | 7.92217 | 5.28357 | 5.59962 |
| SSPA | fiber_full | finite_difference | 0.00078125 | 0.42746 | 2.14417 | 7.92217 | 5.28333 | 5.60377 |
