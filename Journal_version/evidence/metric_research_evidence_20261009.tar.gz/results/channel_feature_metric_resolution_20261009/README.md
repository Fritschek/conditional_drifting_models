# Decoder-free feature metric pilot

Development seed only; no downstream codec is loaded to calculate a score.
Full RBF-kernel empirical embedding norms (V-statistics), not random features.
Analytic row is an independent exact-channel sampling floor, not a subtraction.
CRN shares noise across input perturbations within a simulator; independent mode does not.
Bandwidths are fixed from physical noise, not tuned against downstream results.
Table entries average fixed anchors and Monte Carlo repeats; maxima and MC SE are in JSON.
Finite-panel maxima do not certify population suprema. Historical training budgets differ.

| Channel | Model | Noise pairing | h | SWD | MMD | Embedding derivative | Mean derivative | Covariance derivative |
|---|---|---|---:|---:|---:|---:|---:|---:|
| AWGN | analytic | crn | 0.025 | 0.041006 | 0.046045 | 0.063312 | 6.7801e-08 | 1.6874e-07 |
| AWGN | analytic | crn | 0.05 | 0.041006 | 0.046045 | 0.063208 | 3.6682e-08 | 8.3991e-08 |
| AWGN | analytic | crn | 0.1 | 0.041006 | 0.046045 | 0.062795 | 1.8322e-08 | 4.0585e-08 |
| AWGN | analytic | independent | 0.025 | 0.041006 | 0.046045 | 1.806 | 4.1672 | 5.1298 |
| AWGN | analytic | independent | 0.05 | 0.041006 | 0.046045 | 0.90308 | 2.0836 | 2.5649 |
| AWGN | analytic | independent | 0.1 | 0.041006 | 0.046045 | 0.45145 | 1.0418 | 1.2824 |
| AWGN | fiber_sinkhorn | crn | 0.025 | 0.042521 | 0.048359 | 0.065692 | 0.027864 | 0.019302 |
| AWGN | fiber_sinkhorn | crn | 0.05 | 0.042521 | 0.048359 | 0.06559 | 0.027864 | 0.019302 |
| AWGN | fiber_sinkhorn | crn | 0.1 | 0.042521 | 0.048359 | 0.065185 | 0.027863 | 0.019299 |
| AWGN | fiber_sinkhorn | independent | 0.025 | 0.042521 | 0.048359 | 1.8307 | 4.2796 | 5.0377 |
| AWGN | fiber_sinkhorn | independent | 0.05 | 0.042521 | 0.048359 | 0.91471 | 2.1393 | 2.5189 |
| AWGN | fiber_sinkhorn | independent | 0.1 | 0.042521 | 0.048359 | 0.45659 | 1.0694 | 1.2595 |
| AWGN | ddim10 | crn | 0.025 | 0.067931 | 0.085381 | 0.11024 | 0.011119 | 0.0038836 |
| AWGN | ddim10 | crn | 0.05 | 0.067931 | 0.085381 | 0.11008 | 0.011119 | 0.0038834 |
| AWGN | ddim10 | crn | 0.1 | 0.067931 | 0.085381 | 0.10948 | 0.011117 | 0.0038825 |
| AWGN | ddim10 | independent | 0.025 | 0.067931 | 0.085381 | 1.7741 | 3.881 | 4.5041 |
| AWGN | ddim10 | independent | 0.05 | 0.067931 | 0.085381 | 0.8895 | 1.9405 | 2.2521 |
| AWGN | ddim10 | independent | 0.1 | 0.067931 | 0.085381 | 0.45228 | 0.97029 | 1.1261 |
| AWGN | ddim100 | crn | 0.025 | 0.041828 | 0.047258 | 0.06528 | 0.0096142 | 0.0038557 |
| AWGN | ddim100 | crn | 0.05 | 0.041828 | 0.047258 | 0.065176 | 0.0096138 | 0.0038555 |
| AWGN | ddim100 | crn | 0.1 | 0.041828 | 0.047258 | 0.064761 | 0.0096124 | 0.0038546 |
| AWGN | ddim100 | independent | 0.025 | 0.041828 | 0.047258 | 1.8027 | 4.1352 | 5.0612 |
| AWGN | ddim100 | independent | 0.05 | 0.041828 | 0.047258 | 0.90122 | 2.0677 | 2.5306 |
| AWGN | ddim100 | independent | 0.1 | 0.041828 | 0.047258 | 0.4504 | 1.0339 | 1.2653 |
| SSPA | analytic | crn | 0.025 | 0.018345 | 0.047198 | 0.34366 | 8.271e-08 | 8.5125e-08 |
| SSPA | analytic | crn | 0.05 | 0.018345 | 0.047198 | 0.3128 | 4.5648e-08 | 4.3576e-08 |
| SSPA | analytic | crn | 0.1 | 0.018345 | 0.047198 | 0.2458 | 2.4424e-08 | 2.3028e-08 |
| SSPA | analytic | independent | 0.025 | 0.018345 | 0.047198 | 1.8504 | 2.0939 | 1.0844 |
| SSPA | analytic | independent | 0.05 | 0.018345 | 0.047198 | 0.92209 | 1.0469 | 0.54221 |
| SSPA | analytic | independent | 0.1 | 0.018345 | 0.047198 | 0.45742 | 0.52346 | 0.2711 |
| SSPA | fiber_sinkhorn | crn | 0.025 | 0.038975 | 0.10178 | 0.60212 | 0.41296 | 0.071771 |
| SSPA | fiber_sinkhorn | crn | 0.05 | 0.038975 | 0.10178 | 0.56152 | 0.39988 | 0.071253 |
| SSPA | fiber_sinkhorn | crn | 0.1 | 0.038975 | 0.10178 | 0.46473 | 0.35776 | 0.069251 |
| SSPA | fiber_sinkhorn | independent | 0.025 | 0.038975 | 0.10178 | 1.8446 | 1.975 | 1.0473 |
| SSPA | fiber_sinkhorn | independent | 0.05 | 0.038975 | 0.10178 | 0.99345 | 1.0539 | 0.52526 |
| SSPA | fiber_sinkhorn | independent | 0.1 | 0.038975 | 0.10178 | 0.58388 | 0.60578 | 0.26619 |
| SSPA | ddim10 | crn | 0.025 | 0.051396 | 0.15414 | 1.2038 | 0.39713 | 0.0075809 |
| SSPA | ddim10 | crn | 0.05 | 0.051396 | 0.15414 | 1.0989 | 0.38004 | 0.0075007 |
| SSPA | ddim10 | crn | 0.1 | 0.051396 | 0.15414 | 0.86066 | 0.31613 | 0.0072074 |
| SSPA | ddim10 | independent | 0.025 | 0.051396 | 0.15414 | 2.1192 | 1.8717 | 0.8822 |
| SSPA | ddim10 | independent | 0.05 | 0.051396 | 0.15414 | 1.3776 | 0.9767 | 0.44114 |
| SSPA | ddim10 | independent | 0.1 | 0.051396 | 0.15414 | 0.92553 | 0.54295 | 0.22063 |
| SSPA | ddim100 | crn | 0.025 | 0.023638 | 0.060327 | 0.48436 | 0.37548 | 0.0096207 |
| SSPA | ddim100 | crn | 0.05 | 0.023638 | 0.060327 | 0.43318 | 0.35891 | 0.0095332 |
| SSPA | ddim100 | crn | 0.1 | 0.023638 | 0.060327 | 0.32748 | 0.29918 | 0.0092085 |
| SSPA | ddim100 | independent | 0.025 | 0.023638 | 0.060327 | 1.8596 | 2.0934 | 1.0722 |
| SSPA | ddim100 | independent | 0.05 | 0.023638 | 0.060327 | 0.95402 | 1.0835 | 0.53611 |
| SSPA | ddim100 | independent | 0.1 | 0.023638 | 0.060327 | 0.48853 | 0.58774 | 0.26809 |
| SSPA | fiber_full | crn | 0.025 | 1.733 | 0.41514 | 1.8744 | 0.44636 | 38.397 |
| SSPA | fiber_full | crn | 0.05 | 1.733 | 0.41514 | 1.794 | 0.43653 | 38.361 |
| SSPA | fiber_full | crn | 0.1 | 1.733 | 0.41514 | 1.5705 | 0.40522 | 38.227 |
| SSPA | fiber_full | independent | 0.025 | 1.733 | 0.41514 | 2.6606 | 29.35 | 1024.7 |
| SSPA | fiber_full | independent | 0.05 | 1.733 | 0.41514 | 2.0016 | 14.671 | 514.44 |
| SSPA | fiber_full | independent | 0.1 | 1.733 | 0.41514 | 1.6016 | 7.3354 | 260.19 |
