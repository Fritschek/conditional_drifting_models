# Small transport-reference audit

Uniform masses, cost ||u-v||^2/2, KL relative to product masses.
Float64 log-domain reference, both relative marginal errors <= 1e-8, cap 50,000 iterations.
Production is float32 with its existing floor and denominator stabilizers. Training defaults are unchanged.

Reference cases: 24; unconverged cases: [('broad', 0.001)].
Unconverged cases have no reported error against the intended OT solution.

## Projection errors

Barycenter errors are RMS per output coordinate, not normalized by cloud scale.
Floor-reference error includes quantization of the production float32 kernel.

| Case | Epsilon | Iterations | Raw row residual | Normalized target residual | Floor fraction | Barycenter error | Converged floored-kernel error |
|---|---:|---:|---:|---:|---:|---:|---:|
| identical | 0.001 | 10 | 0 | 0 | 0.75 | 1.56992e-08 | 1.49623e-08 |
| identical | 0.001 | 30 | 0 | 0 | 0.75 | 1.56992e-08 | 1.49623e-08 |
| identical | 0.001 | 100 | 0 | 0 | 0.75 | 1.56992e-08 | 1.49623e-08 |
| identical | 0.05 | 10 | 0.00430512 | 0.00409275 | 0.125 | 0.000677086 | 4.21719e-09 |
| identical | 0.05 | 30 | 0.000527859 | 0.000509977 | 0.125 | 0.000117647 | 4.21719e-09 |
| identical | 0.05 | 100 | 0.000324726 | 0.000323832 | 0.125 | 6.84874e-05 | 4.21719e-09 |
| identical | 1.0 | 10 | 5.96046e-08 | 1.19209e-07 | 0 | 2.80445e-08 | 3.45523e-09 |
| identical | 1.0 | 30 | 5.96046e-08 | 1.19209e-07 | 0 | 2.80445e-08 | 3.45523e-09 |
| identical | 1.0 | 100 | 5.96046e-08 | 1.19209e-07 | 0 | 2.80445e-08 | 3.45523e-09 |
| unequal_4x7 | 0.001 | 10 | 0.0987542 | 0.130766 | 0.821429 | 0.172979 | 0.185446 |
| unequal_4x7 | 0.001 | 30 | 0.0349042 | 0.0468279 | 0.821429 | 0.180138 | 0.185446 |
| unequal_4x7 | 0.001 | 100 | 0.0103225 | 0.0138021 | 0.821429 | 0.183782 | 0.185446 |
| unequal_4x7 | 0.05 | 10 | 0.0536249 | 0.0532832 | 0.107143 | 0.0267212 | 2.29523e-05 |
| unequal_4x7 | 0.05 | 30 | 0.00605375 | 0.00599754 | 0.107143 | 0.00242719 | 2.29523e-05 |
| unequal_4x7 | 0.05 | 100 | 0.00015074 | 0.000880599 | 0.107143 | 0.000138505 | 2.29523e-05 |
| unequal_4x7 | 1.0 | 10 | 1.19209e-07 | 5.96046e-08 | 0 | 1.41969e-08 | 4.51668e-09 |
| unequal_4x7 | 1.0 | 30 | 5.96046e-08 | 5.96046e-08 | 0 | 1.41969e-08 | 4.51668e-09 |
| unequal_4x7 | 1.0 | 100 | 5.96046e-08 | 5.96046e-08 | 0 | 1.41969e-08 | 4.51668e-09 |
| near_duplicates | 0.001 | 10 | 0.998739 | 0.499116 | 0.5 | 0.0455627 | 2.8689e-06 |
| near_duplicates | 0.001 | 30 | 0.00124329 | 0.0012449 | 0.5 | 0.000113674 | 2.8689e-06 |
| near_duplicates | 0.001 | 100 | 0.00114423 | 0.0011456 | 0.5 | 0.000104613 | 2.8689e-06 |
| near_duplicates | 0.05 | 10 | 0 | 5.96046e-08 | 0 | 2.47176e-09 | 2.07404e-09 |
| near_duplicates | 0.05 | 30 | 0 | 5.96046e-08 | 0 | 2.47176e-09 | 2.07404e-09 |
| near_duplicates | 0.05 | 100 | 0 | 5.96046e-08 | 0 | 2.47176e-09 | 2.07404e-09 |
| near_duplicates | 1.0 | 10 | 1.19209e-07 | 1.19209e-07 | 0 | 6.81069e-09 | 4.2029e-10 |
| near_duplicates | 1.0 | 30 | 1.19209e-07 | 1.19209e-07 | 0 | 6.81069e-09 | 4.2029e-10 |
| near_duplicates | 1.0 | 100 | 1.19209e-07 | 1.19209e-07 | 0 | 6.81069e-09 | 4.2029e-10 |
| concentrated | 0.001 | 10 | 1.19209e-07 | 1.78814e-07 | 0 | 3.33724e-09 | 7.53277e-10 |
| concentrated | 0.001 | 30 | 1.19209e-07 | 2.38419e-07 | 0 | 1.55732e-09 | 7.53277e-10 |
| concentrated | 0.001 | 100 | 1.19209e-07 | 2.38419e-07 | 0 | 1.55732e-09 | 7.53277e-10 |
| concentrated | 0.05 | 10 | 0 | 1.19209e-07 | 0 | 2.76445e-09 | 8.58237e-11 |
| concentrated | 0.05 | 30 | 0 | 1.19209e-07 | 0 | 2.76445e-09 | 8.58237e-11 |
| concentrated | 0.05 | 100 | 0 | 1.19209e-07 | 0 | 2.76445e-09 | 8.58237e-11 |
| concentrated | 1.0 | 10 | 0 | 1.19209e-07 | 0 | 1.59008e-09 | 6.3098e-11 |
| concentrated | 1.0 | 30 | 0 | 1.19209e-07 | 0 | 1.59008e-09 | 6.3098e-11 |
| concentrated | 1.0 | 100 | 0 | 1.19209e-07 | 0 | 1.59008e-09 | 6.3098e-11 |
| broad | 0.001 | 10 | 0.204048 | 0.173888 | 0.8 | unresolved | unresolved |
| broad | 0.001 | 30 | 0.196924 | 0.163828 | 0.8 | unresolved | unresolved |
| broad | 0.001 | 100 | 0.000632703 | 0.00071615 | 0.8 | unresolved | unresolved |
| broad | 0.05 | 10 | 0.204048 | 0.173888 | 0.8 | 2.84518 | 2.82821 |
| broad | 0.05 | 30 | 0.196924 | 0.163828 | 0.8 | 2.87978 | 2.82821 |
| broad | 0.05 | 100 | 0.000632703 | 0.00071615 | 0.8 | 2.82761 | 2.82821 |
| broad | 1.0 | 10 | 0.202389 | 0.180037 | 0.666667 | 2.85551 | 2.81342 |
| broad | 1.0 | 30 | 0.196845 | 0.16376 | 0.666667 | 2.88953 | 2.81342 |
| broad | 1.0 | 100 | 0.000379443 | 0.00085324 | 0.666667 | 2.81261 | 2.81342 |
| separated | 0.001 | 10 | 0.0916854 | 0.10094 | 0.75 | 0.0702795 | 0.0701674 |
| separated | 0.001 | 30 | 0.0327616 | 0.0338712 | 0.75 | 0.0701801 | 0.0701674 |
| separated | 0.001 | 100 | 0.0099889 | 0.0100896 | 0.75 | 0.0701686 | 0.0701674 |
| separated | 0.05 | 10 | 0.0916854 | 0.10094 | 0.75 | 0.0069539 | 0.0057113 |
| separated | 0.05 | 30 | 0.0327616 | 0.0338712 | 0.75 | 0.00586448 | 0.0057113 |
| separated | 0.05 | 100 | 0.0099889 | 0.0100896 | 0.75 | 0.0057251 | 0.0057113 |
| separated | 1.0 | 10 | 5.96046e-08 | 5.96046e-08 | 0 | 2.72308e-07 | 4.52405e-08 |
| separated | 1.0 | 30 | 5.96046e-08 | 5.96046e-08 | 0 | 2.72308e-07 | 4.52405e-08 |
| separated | 1.0 | 100 | 5.96046e-08 | 5.96046e-08 | 0 | 2.72308e-07 | 4.52405e-08 |
| cluster_occupancy | 0.001 | 10 | 0.0373704 | 0.0128672 | 0.625 | 0.0148579 | 3.60259e-09 |
| cluster_occupancy | 0.001 | 30 | 0.00019455 | 0.00019455 | 0.625 | 0.000224679 | 3.60259e-09 |
| cluster_occupancy | 0.001 | 100 | 0.000192523 | 0.000192523 | 0.625 | 0.000222408 | 3.60259e-09 |
| cluster_occupancy | 0.05 | 10 | 0.0373704 | 0.0128672 | 0.625 | 0.0148579 | 1.26597e-11 |
| cluster_occupancy | 0.05 | 30 | 0.00019455 | 0.00019455 | 0.625 | 0.000224681 | 1.26597e-11 |
| cluster_occupancy | 0.05 | 100 | 0.000192523 | 0.000192523 | 0.625 | 0.00022241 | 1.26597e-11 |
| cluster_occupancy | 1.0 | 10 | 1.3113e-06 | 1.19209e-06 | 0 | 1.59635e-06 | 3.22682e-15 |
| cluster_occupancy | 1.0 | 30 | 9.53674e-07 | 8.34465e-07 | 0 | 1.23502e-06 | 3.22682e-15 |
| cluster_occupancy | 1.0 | 100 | 1.07288e-06 | 9.53674e-07 | 0 | 1.23502e-06 | 3.22682e-15 |
| collapsed | 0.001 | 10 | 0 | 0 | 0 | 0 | 0 |
| collapsed | 0.001 | 30 | 0 | 0 | 0 | 0 | 0 |
| collapsed | 0.001 | 100 | 0 | 0 | 0 | 0 | 0 |
| collapsed | 0.05 | 10 | 0 | 0 | 0 | 0 | 0 |
| collapsed | 0.05 | 30 | 0 | 0 | 0 | 0 | 0 |
| collapsed | 0.05 | 100 | 0 | 0 | 0 | 0 | 0 |
| collapsed | 1.0 | 10 | 0 | 0 | 0 | 0 | 0 |
| collapsed | 1.0 | 30 | 0 | 0 | 0 | 0 | 0 |
| collapsed | 1.0 | 100 | 0 | 0 | 0 | 0 | 0 |

## SSPA-shaped clouds

Synthetic outputs at eight anchors, four outputs per cloud. No trained-generator trajectory.
Policy differences below change the field; they are not themselves numerical errors.

| Policy | Iterations | Cross epsilon | Self epsilon | Drift RMS error | Raw row residual | Reference field difference from fixed common |
|---|---:|---:|---:|---:|---:|---:|
| fixed_common | 10 | 0.353474 | 0.353474 | 2.10323e-07 | 7.51019e-06 | 0 |
| fixed_common | 30 | 0.353474 | 0.353474 | 9.07616e-08 | 1.19209e-07 | 0 |
| fixed_common | 100 | 0.353474 | 0.353474 | 9.07616e-08 | 1.19209e-07 | 0 |
| shared_adaptive | 10 | 0.746384 | 0.746384 | 9.28482e-08 | 1.19209e-07 | 0.0456823 |
| shared_adaptive | 30 | 0.746384 | 0.746384 | 9.09667e-08 | 1.19209e-07 | 0.0456823 |
| shared_adaptive | 100 | 0.746384 | 0.746384 | 9.09667e-08 | 1.19209e-07 | 0.0456823 |
| legacy_separate_adaptive | 10 | 0.75482 | 0.735207 | 8.00458e-08 | 1.19209e-07 | 0.0452027 |
| legacy_separate_adaptive | 30 | 0.75482 | 0.735207 | 7.9705e-08 | 1.19209e-07 | 0.0452027 |
| legacy_separate_adaptive | 100 | 0.75482 | 0.735207 | 7.9705e-08 | 1.19209e-07 | 0.0452027 |
| historical_global_scale | 10 | 9.50381 | 9.42864 | 9.06262e-08 | 1.19209e-07 | 0.0935957 |
| historical_global_scale | 30 | 9.50381 | 9.42864 | 9.06262e-08 | 1.19209e-07 | 0.0935957 |
| historical_global_scale | 100 | 9.50381 | 9.42864 | 9.06262e-08 | 1.19209e-07 | 0.0935957 |

## Mathematical checks

Parameter finite-difference error: 6.78149e-12.
Detached-MSE scaling identity error: 2.18495e-13.
Independent same-generator reference changes the sampled field by norm 0.476252.
The independent-reference field is not compared as an approximation of the same-batch objective gradient.
Collapsed symmetric examples all have zero velocity and positive divergence; identical-law checks give zero divergence.

These controls validate a restricted instantaneous gradient identity and expose numerical failure regimes.
They neither explain the historical SSPA training degradation nor establish convergence of neural training.
All full inputs, couplings and source snapshots are retained in the raw result directory.
