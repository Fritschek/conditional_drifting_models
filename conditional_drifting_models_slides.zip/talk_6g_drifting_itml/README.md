# 6G Conference Talk: ITML Template Version

This is the ITML/TUD-template version of the conference deck. It contains 27 main slides and 12 backup slides. The complete slide-by-slide purpose, content, transition, and speaker narrative are in `storyboard.md`.

Build from this directory with:

```bash
TEXINPUTS=itml/moloch//:../texmf//: pdflatex -interaction=nonstopmode -halt-on-error slides.tex
TEXINPUTS=itml/moloch//:../texmf//: pdflatex -interaction=nonstopmode -halt-on-error slides.tex
```

The deck reuses three manuscript figures directly from `../Journal_version/figures/` and draws the conceptual material in TikZ.
